#ifndef AUTHENTIFICATION_H
#define AUTHENTIFICATION_H
#include "mainwindow.h"
#include <QDialog>
#include <QApplication>

namespace Ui {
class Authentification;
}

class Authentification : public QDialog
{
    Q_OBJECT

public:
    explicit Authentification(QWidget *parent = nullptr);
    ~Authentification();

private:
    Ui::Authentification *ui;
    MainWindow w;

public slots:

    void on_connexion_clicked();

};

#endif // AUTHENTIFICATION_H
