#include "Materiel.h"
#include <iostream>
#include <QDebug>
#include <QtSql>
using namespace std;

Materiel::Materiel(){
    this->id=0;
    this->type="";
    this->quantite=0;
}

Materiel::Materiel(int id, QString type, int quantite){
    this->id=id;
    this->type=type;
    this->quantite=quantite;



}

QSqlQueryModel * Materiel::afficher_id()

{
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select ID from matériel");
   //pour afficher les ids sélectionnées à partir de la requête et résultant dans model.

    return model;
}

QSqlQueryModel * Materiel::trier_id()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("Select * from matériel\
                         Order by ID ASC");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Quantite"));


    return model;
}

QSqlQueryModel * Materiel::trier_type()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("Select * from matériel\
                         Order by type ASC");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Quantite"));

    return model;
}

bool Materiel::ajouter(){
    QSqlQuery query;
    QString id_res= QString::number(id);
    query.prepare("INSERT INTO Matériel (ID, Type, Quantite) "
                        "VALUES (:id, :type, :quantite)");
    query.bindValue(":id", id_res);
    query.bindValue(":type", type);
    query.bindValue(":quantite", quantite);
    return    query.exec();
}

bool Materiel::modifier(){
    QSqlQuery query;
    QString id_res= QString::number(id);
    query.prepare("UPDATE Matériel SET quantite = :quantite  , type = :type where ID = :id");
    query.bindValue(":id", id_res);
    query.bindValue(":quantite", quantite);
    query.bindValue(":type", type);
    return    query.exec();
}





QSqlQueryModel * Materiel::afficher()
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select ID,TYPE,QUANTITE from Matériel");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("QUANTITE"));

    return model;
}

QSqlQueryModel * Materiel::afficher(QString type)
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select ID,TYPE,QUANTITE from Matériel where TYPE like '" + type + "%' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("QUANTITE"));

    return model;
}


bool Materiel::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from Matériel where ID = :id");
query.bindValue(":id", res);
return    query.exec();
}


QString Materiel::getType(){

    return type;

}

int Materiel::getQuantite(){

    return quantite;

}

int Materiel::get_id(){

    return id;
}
