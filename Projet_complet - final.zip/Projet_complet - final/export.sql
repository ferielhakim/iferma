--------------------------------------------------------
--  Fichier cr�� - vendredi-avril-24-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ACHAT
--------------------------------------------------------

  CREATE TABLE "DHIA"."ACHAT" 
   (	"ID_FOURNISSEUR" NUMBER, 
	"PRIX" NUMBER, 
	"QUANTITE" NUMBER, 
	"DATE_ACHAT" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into DHIA.ACHAT
SET DEFINE OFF;
Insert into DHIA.ACHAT (ID_FOURNISSEUR,PRIX,QUANTITE,DATE_ACHAT) values ('1','2233','33333',to_date('01/01/00','DD/MM/RR'));
Insert into DHIA.ACHAT (ID_FOURNISSEUR,PRIX,QUANTITE,DATE_ACHAT) values ('2','2222','8888',to_date('08/02/10','DD/MM/RR'));
Insert into DHIA.ACHAT (ID_FOURNISSEUR,PRIX,QUANTITE,DATE_ACHAT) values ('3','5555','7543',to_date('01/01/00','DD/MM/RR'));
--------------------------------------------------------
--  DDL for Index ACHAT_UK1
--------------------------------------------------------

  CREATE UNIQUE INDEX "DHIA"."ACHAT_UK1" ON "DHIA"."ACHAT" ("ID_FOURNISSEUR") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table ACHAT
--------------------------------------------------------

  ALTER TABLE "DHIA"."ACHAT" ADD CONSTRAINT "ACHAT_UK1" UNIQUE ("ID_FOURNISSEUR")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ACHAT
--------------------------------------------------------

  ALTER TABLE "DHIA"."ACHAT" ADD CONSTRAINT "ACHAT_FK1" FOREIGN KEY ("ID_FOURNISSEUR")
	  REFERENCES "DHIA"."FOURNISSEUR" ("ID_FOURNISSEUR") ENABLE;
