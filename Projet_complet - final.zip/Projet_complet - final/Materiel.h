#ifndef MATERIEL_H
#define MATERIEL_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class Materiel
{
    public:
    Materiel();
    Materiel(int id, QString type, int quantite);
    bool modifier();
    QSqlQueryModel * afficher();
    QSqlQueryModel * afficher(QString type);
    QSqlQueryModel * afficher_id();
    bool ajouter();
    bool supprimer(int idd);

    int getQuantite();
    QString getType();
    int get_id();

    QSqlQueryModel * trier_id();
    QSqlQueryModel * trier_type();

    private:

    int id;
    QString type;
    int quantite;



};

#endif // MATERIEL_H
