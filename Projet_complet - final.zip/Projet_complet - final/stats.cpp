#include "stats.h"
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QDebug>
#include <string>
#include <QPainter>
#include <QMessageBox>
#include <QSqlQuery>
#include <QtCharts/QPieSlice>

QT_CHARTS_USE_NAMESPACE

Stats::Stats(){

}

QChartView * Stats::Preparechart(){
    QSqlQuery query;
    QSqlQuery query1;
       int count1=0;
       int id=0;
       QString idd="";
       QPieSeries *series;
       series = new QPieSeries();
       if(query.exec("select ID_FOURNISSEUR,QUANTITE from ACHAT"))
       {
       while(query.next())
         {
           id=query.value(0).toInt();
           count1=query.value(1).toInt();
          QString res=QString::number(id);
           query1.prepare("select NOM from FOURNISSEUR where IDF= :id");
           query1.bindValue(":id",res);
           if (query1.exec())
           {
               while (query1.next())
               {
                   idd=query1.value(0).toString();
                   series->append(idd,count1);

               }
           }

          }
        }

       series->setLabelsVisible();
       series->setLabelsPosition(QPieSlice::LabelInsideHorizontal);
       for(auto slice : series->slices())
           slice->setLabel(QString("%1 %2%").arg(slice->label()).arg(100*slice->percentage(), 0, 'f', 1));
       chart = new QChart();
       chart->addSeries(series);
       chart->setTitle("Statistiques de la quantité de produits par fournisseur");
       chart->setAnimationOptions(QChart::AllAnimations);
       chartView = new QChartView(chart);
       chartView->setRenderHint(QPainter::Antialiasing);
       QChart::ChartTheme theme = QChart::ChartThemeBlueCerulean ;
       chartView->chart()->setTheme(theme);

       return chartView;
}
