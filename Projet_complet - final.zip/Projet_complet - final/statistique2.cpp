#include "statistique2.h"
#include "connexion.h"
#include <QDebug>
#include <QSqlRecord>


Statistique2::Statistique2()
{

}

Statistique2::Statistique2(int Id, QDateTime S_Date)
{
    this->Id=Id;
    this->S_Date=S_Date;
}


QSqlQueryModel * Statistique2::afficherstats()
{
/*    connexion c;
    c.ouvrirConnexion();*/
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select m.type as type, count(1) as occur, sum(cout) as somme from matériel m inner join maintien mt on m.id = mt.matériel_id group by m.type order by count(1) desc");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("type"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("occur"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("somme"));

        return model;
}



