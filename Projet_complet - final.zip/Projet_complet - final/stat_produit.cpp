#include "stat_produit.h"
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QDebug>
#include <QSqlQuery>
#include <QtCharts/QPieSeries>
#include <QMessageBox>


QT_CHARTS_USE_NAMESPACE

Stat_produit::Stat_produit(){

}

QChartView * Stat_produit::Preparechart(){
    QSqlQuery query;
       int count1=0;
       int count2=0;

       if(query.exec("select type from produit"))
       {
           while(query.next())
             {
                if(query.value(0).toString()=="a vendre"){
                    count1++; }
                else if(query.value(0).toString()=="a acheter"){
                    count2++;}
              }
        }
       QPieSeries *Series;
       Series = new QPieSeries();
       Series->append("produit vendu", count1);
       Series->append("produit acheté", count2);
       Series->setLabelsVisible();
       Series->setLabelsPosition(QPieSlice::LabelInsideHorizontal);
       for(auto slice : Series->slices())
           slice->setLabel(QString("%1 %2%").arg(slice->label()).arg(100*slice->percentage(), 0, 'f', 1));
       QChart *chart = new QChart();
       chart->addSeries(Series);
       chart->setTitle("Statistique du type des produits");
       QChartView *chartView = new QChartView(chart);
       chartView->setRenderHint(QPainter::Antialiasing);
       chartView->setRenderHint(QPainter::Antialiasing);
       QChart::ChartTheme theme = QChart::ChartThemeBlueCerulean ;
       chartView->chart()->setTheme(theme);


       return chartView;
}

