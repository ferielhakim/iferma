--------------------------------------------------------
--  Fichier cr�� - vendredi-avril-24-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table VENTE
--------------------------------------------------------

  CREATE TABLE "DHIA"."VENTE" 
   (	"MATRICULE_CLT" NUMBER, 
	"QUANTITE" NUMBER, 
	"PRIX" NUMBER, 
	"DATE_VENTE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into DHIA.VENTE
SET DEFINE OFF;
Insert into DHIA.VENTE (MATRICULE_CLT,QUANTITE,PRIX,DATE_VENTE) values ('10','555','2222',to_date('01/01/00','DD/MM/RR'));
Insert into DHIA.VENTE (MATRICULE_CLT,QUANTITE,PRIX,DATE_VENTE) values ('20','2000','2000',to_date('01/01/00','DD/MM/RR'));
Insert into DHIA.VENTE (MATRICULE_CLT,QUANTITE,PRIX,DATE_VENTE) values ('30','5555','253',to_date('01/01/07','DD/MM/RR'));
--------------------------------------------------------
--  DDL for Index VENTE_UK1
--------------------------------------------------------

  CREATE UNIQUE INDEX "DHIA"."VENTE_UK1" ON "DHIA"."VENTE" ("MATRICULE_CLT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table VENTE
--------------------------------------------------------

  ALTER TABLE "DHIA"."VENTE" ADD CONSTRAINT "VENTE_UK1" UNIQUE ("MATRICULE_CLT")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table VENTE
--------------------------------------------------------

  ALTER TABLE "DHIA"."VENTE" ADD CONSTRAINT "MATRICULE_CLT" FOREIGN KEY ("MATRICULE_CLT")
	  REFERENCES "DHIA"."CLIENT" ("MATRICULE_CLT") ENABLE;
