#ifndef STATISTIQUE2_H
#define STATISTIQUE2_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDateTime>

class Statistique2
{


public:
    Statistique2();
    Statistique2(int Id, QDateTime S_Date);
    QSqlQueryModel * afficherstats();
    bool ajouter();

private:
    int Id;
    QDateTime S_Date;


};
#endif // STATISTIQUE2_H
