#ifndef AGENT_H
#define AGENT_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDateTime>
class Agent
{
public:
    Agent();
    Agent(int Id, QString entreprise, QString Nom);
    QSqlQueryModel * afficher_id();
    QSqlQueryModel * afficher();
    //QSqlQueryModel * afficher(QString entreprise1, QString entreprise2);


    bool ajouter();
    bool modifier();
    bool supprimer(int idd);


private:

    int Id;
    QString entreprise;
    QString Nom;
};

#endif // AGENT_H
