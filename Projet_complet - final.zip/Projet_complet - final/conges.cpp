#include "conges.h"
#include "ouvriers.h"
#include <QDebug>
conges::conges()
{
 idCon=0;
 idOuv=0;
 nomOuv="";
 duree=0;
 p_nonp="paye";
}
conges::conges(int idCon,int idOuv,QString nomOuv,int duree,QDate dateDebut,QString p_nonp)
{
    this->idCon=idCon;
    this->idOuv=idOuv;
    this->nomOuv=nomOuv;
    this->duree=duree;
    this->dateDebut=dateDebut;
    this->p_nonp=p_nonp;
}

int conges::get_idCon(){return idCon;}
int conges::get_idOuv(){return idOuv;}
QString conges::get_nomOuv(){return nomOuv;}
int conges::get_duree(){return duree;}
QDate conges::get_dateDebut(){return dateDebut;}
QString conges::get_p_nonp(){return p_nonp;}

bool conges::ajouterC()
{
    QSqlQuery query,query1,query2;
    QString res= QString::number(idCon);
    QString res1= QString::number(idOuv);
    QString res2= QString::number(duree);

    query.prepare("INSERT INTO CONGES (ID_CON, ID_OUV, NOM_OUV, DUREE, DATE_D, P_NONP) "
                        "VALUES (:idCon, :idOuv, :nomOuv, :duree, :dateDebut, :p_nonp)");
    query.bindValue(":idCon", res);
    query.bindValue(":idOuv",res1);
    query.bindValue(":nomOuv",nomOuv);
    query.bindValue(":duree",res2);
    query.bindValue(":dateDebut",dateDebut);
    query.bindValue(":p_nonp",p_nonp);
    qDebug()<<p_nonp;
    if(p_nonp=="NonPaye")
    {
        int salaireM;
         query2.prepare("select SALAIRE_M from OUVRIERS where ID_OUV =:idOuv");
         query2.bindValue(":idOuv",res1);
          query2.exec();

          if(query2.exec())
          {
              while (query2.next()) {
                  salaireM=query2.value(0).toInt();
                  // qDebug()<<salaireM;


                   int c= salaireM -((salaireM/30)*duree);

                   QString res3= QString::number(c);
                   query1.prepare("update ouvriers SET ID_OUV=:idOuv, SALAIRE_M=:c where ID_OUV =:idOuv");
                    query1.bindValue(":idOuv",res1);
                   query1.bindValue(":c",res3);
                   query1.exec();
              }
          }
    }

    return    query.exec();
}

QSqlQueryModel * conges::afficherC()
{

    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from CONGES order by ID_CON ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID Congé"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID Ouvrier "));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Nom ouvrier"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Durée"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Date Début"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("Payé/NonPayé"));
        return model;
}
QSqlQueryModel * conges::afficherC1()
{

    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from CONGES order by DUREE ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID Congé"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID Ouvrier "));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Nom ouvrier"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Durée"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Date Début"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("Payé/NonPayé"));
        return model;
}
bool conges::supprimerC(int id)
{
QSqlQuery query;
QString res= QString::number(id);
query.prepare("Delete from CONGES where ID_CON = :id");
query.bindValue(":id", res);
return    query.exec();
}
QSqlQueryModel * conges::chercherC(const QString &id)
{
    QSqlQueryModel * model=new QSqlQueryModel;
   model->setQuery("select * from CONGES where (ID_CON LIKE '"+id+"%')");
   model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID Congé"));
   model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID Ouvrier "));
   model->setHeaderData(2, Qt::Horizontal, QObject::tr("Nom ouvrier"));
   model->setHeaderData(3, Qt::Horizontal, QObject::tr("Durée"));
   model->setHeaderData(4, Qt::Horizontal, QObject::tr("Date Début"));
   model->setHeaderData(5, Qt::Horizontal, QObject::tr("Payé/NonPayé"));
    return model;
}
bool conges::modifierC(int idCon)
{
    QSqlQuery query;

    QString res= QString::number(idCon);
    QString res1= QString::number(idOuv);
    QString res2= QString::number(duree);

    query.prepare("update CONGES SET ID_CON=:idCon,ID_OUV=:idOuv,NOM_OUV=:nomOuv,DUREE=:duree,DATE_D=:dateDebut,P_NONP=:p_nonp where ID_CON =:idCon");
    query.bindValue(":idCon", res);
    query.bindValue(":idOuv",res1);
    query.bindValue(":nomOuv",nomOuv);
    query.bindValue(":duree",res2);
    query.bindValue(":dateDebut",dateDebut);
    query.bindValue(":p_nonp",p_nonp);

    return query.exec();

}

int conges::chercherCon(int id, QDate date)
{
    QSqlQuery query;
    int i=0;
    QDate exp;
    QString res1= QString::number(id);
    query.prepare("select DATE_D from CONGES where ID_OUV=:id");
    query.bindValue(":id",id);
    if (query.exec())
       {
           while (query.next()) {

                                  exp = query.value(0).toDate();
                                  if(exp==date)
                                     i=1;
                                }
       }
       return i;
}
