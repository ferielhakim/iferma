#ifndef CONGES_H
#define CONGES_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDate>
class conges
{
public:
    conges();
    conges(int,int,QString,int,QDate,QString);
    int get_idCon();
    int get_idOuv();
    QString get_nomOuv();
    int get_duree();
    QDate get_dateDebut();
    QString get_p_nonp();


    bool ajouterC();
    QSqlQueryModel * afficherC();
     QSqlQueryModel * afficherC1();
    bool supprimerC(int);
   QSqlQueryModel * chercherC(const QString &);
   bool modifierC(int);
   int chercherCon(int,QDate);


private:
   int idCon,idOuv,duree;
    QString nomOuv,p_nonp;
    QDate dateDebut;

};

#endif // CONGES_H
