#ifndef CLIENT_H
#define CLIENT_H

#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class Client
{
public:
    Client();
    Client(int,QString,QString);
    int get_CIN();
    QString get_nom();
    QString get_prenom();

    //fonctions CRUD
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(int);
    bool modifier();
    QSqlQueryModel * combo_box();
    //fonctions avancées
    QSqlQueryModel * recherche_CIN(int);
     //QSqlQueryModel*  recherche(int x,int i);
    QSqlQueryModel * recherche_nom(QString);
    QSqlQueryModel * trier_CIN();
private:
    QString nom,prenom;
    int CIN,matriculeCl;
};

#endif // CLIENT_H
