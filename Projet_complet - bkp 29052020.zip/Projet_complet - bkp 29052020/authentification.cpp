#include "authentification.h"
#include "ui_authentification.h"
#include "mainwindow.h"

#include <QMessageBox>
#include <QApplication>
#include <QPushButton>
#include <QtDebug>
#include <QDebug>

Authentification::Authentification(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Authentification)
{
    ui->setupUi(this);
}

Authentification::~Authentification()
{
    delete ui;
}
void Authentification::on_connexion_clicked()
{

    if((ui->pseudo->text()=="admin") && (ui->mdp->text()=="admin"))
    {
            QMessageBox::information(nullptr, QObject::tr("Se connecter"),
                        QObject::tr("Connexion réussie.\n"
                                    "Cliquez sur ok pour continuer."), QMessageBox::Ok);
            w.show();
            w.display_listes();
            w.display_commandes();
            w.display_list_client_fournisseur_produit();
    }
    else
    {
        QMessageBox::information(nullptr, QObject::tr("Se connecter"),
                    QObject::tr("La connexion a échoué.\n"
                                "Veuillez réessayer."), QMessageBox::Cancel);
    }

}

