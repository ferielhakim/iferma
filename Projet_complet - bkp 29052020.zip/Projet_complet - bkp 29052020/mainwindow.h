#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include "animaux.h"
#include "fiche_suivi.h"
#include "stat.h"
#include "veterinaire.h"
#include "stat_suivi.h"
#include "conges.h"
#include "ouvriers.h"
#include "achat.h"
#include "vente.h"
#include "stats.h"
#include "client.h"
#include "fournisseur.h"
#include "produit.h"
#include "stat_produit.h"
#include "Agent.h"
#include "maintien.h"
#include "Materiel.h"
#include <statistique2.h>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public:
    void display_listes();

    void display_commandes();

    void display_list_client_fournisseur_produit();

    void refresh_stat_animaux();

    void refresh_stat_fiche();



private slots:

    void on_ajouter_animal_clicked();

    void on_modif_animal_clicked();

    void on_supprimer_animal_clicked();

    void on_rech_an_textChanged(const QString &arg);

    void on_ajouter_fiche_clicked();

    void on_modif_fiche_clicked();

    void on_supprimer_fiche_clicked();

    void on_rech_fiche_textChanged(const QString &arg1);

    void on_trier_currentTextChanged(const QString &arg1);

    void on_trier_fiche_currentTextChanged(const QString &arg1);

    void on_imprimer_animal_clicked();

    void on_imprimer_fiche_clicked();

    void on_ajouter_vet_clicked();

    void on_modif_vet_clicked();

    void on_supprimer_vet_clicked();

    void on_trier_vet_currentTextChanged(const QString &arg1);

    void on_rech_vet_textChanged(const QString &arg2);

    void on_imprimer_vet_clicked();

    void on_pb_AjouterOuv_clicked();

    void on_pb_SupprimerOuv_clicked();

    void on_pb_ok1_clicked();

    void on_tabouvriers_activated(const QModelIndex &index);

    void on_pb_ModifierOuv_clicked();

    void on_comboBox_activated(const QString &arg1);

    void on_pb_AjouterCon_clicked();

    void on_pb_SupprimerCon_clicked();

    void on_pb_ok2_clicked();

    void on_tabconges_activated(const QModelIndex &index);

    void on_pb_ModifierCon_clicked();

    void on_comboBox_2_activated(const QString &arg1);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_id_modif_currentTextChanged(const QString &arg1);

    void on_num_modif_currentTextChanged(const QString &arg1);

    void on_mat_modif_currentTextChanged(const QString &arg1);

    void on_pb_ajouter_clicked();

    void on_pb_supprimer_clicked();

    void on_pb_modifier_clicked();

    void on_pb_trier_clicked();

    void on_ajouter_vente_clicked();

    void on_supprimer_vente_clicked();

    void on_modifier_vente_clicked();

    void on_Trier_clicked();

    void on_imprimer_clicked();

    void on_imprimerV_clicked();

    void on_chercher_id_activated(const QString &arg1);

    void on_chercher_matricule_activated(const QString &arg1);

    void on_modifier_matricule_activated(const QString &arg1);

    void on_modifier_id_activated(const QString &arg1);

    void refresh_stats();

    void on_pb_ajouterCL_clicked();

    void on_pb_supprimerCL_clicked();

    void on_pb_modifierCL_clicked();

    void on_pb_ajouterF_clicked();

    void on_pb_supprimerF_clicked();

    void on_pb_modifierF_clicked();


    void on_ch_nom_clicked();


    void on_nomch_windowIconTextChanged(const QString &arg);

    void on_ch_cin_clicked();


    void on_cinch_windowIconTextChanged(const QString &iconText);

    void on_ch_cin_3_clicked();

    void on_cinch_3_windowIconTextChanged(const QString &iconText);

    void on_ch_nom_3_clicked();

    void on_nomch_3_windowIconTextChanged(const QString &iconText);

    void on_trier_cin_clicked();

    void on_trier_id_clicked();

    void on_pb_ajouterP_clicked();

    void on_pb_supprimerP_clicked();

    void on_pb_modifierP_clicked();

    void on_rech_ref_clicked();

    void on_ref_rech_windowIconTextChanged(const QString &iconText);

    void on_trie_ref_clicked();

    void on_tabWidget_7_currentChanged(int index);

    void on_combo_trie_rech_currentTextChanged(const QString &arg1);

    void on_combo_line_textChanged(const QString &arg1);

    //void on_combocombo_currentIndexChanged(const QString &arg1);

    void on_comboCINmodif_activated(const QString &arg1);

    void on_comboFmodif_activated(const QString &arg1);

    void refresh_stat();

    void on_rechercheButton_clicked();

         void on_pb_ajouter_1_clicked();

         void on_pb_ajouter_3_clicked();

         void on_pb_modifier_M_clicked();

         void on_pb_modifier_2_clicked();

         void on_tabModifierMaintien_tabBarClicked();

         //void on_pushButton_clicked();

         void on_pb_Supprimer_1_clicked();

         void on_pb_Supprimer_2_clicked();

         void on_tabSuppMaintien_tabBarClicked();

         void on_crud_maintenance_tabBarClicked();
         void on_crud_materiel_tabBarClicked();

         void on_tabWidget_M_currentChanged();


         void on_crud_materiel_currentChanged();

         void on_crud_maintenance_currentChanged();

         void on_crud_Ag_M_currentChanged();

         void on_pb_Ag_ajouter_clicked();

         void on_pb_Ag_modifier_clicked();

         void on_pb_Ag_Supp_clicked();


         void on_Statistiques_maintenance_customContextMenuRequested();


         void on_comboBox_5_currentTextChanged(const QString &arg1);

private:
    Ui::MainWindow *ui;
    animaux tmp_animal;
    Fiche_suivi tmp_fiche;
    Veterinaire tmp_vet;
    Achat tmpachat;
    VENTE tmpvente;
    Client tmpclient;
    fournisseur tmpfournisseur;
    produit tmpproduit;
    QVBoxLayout * mainLayout;
    QVBoxLayout * mainLayout2;
    Stats s1;
    Stat s;
    Stat_suivi s2;
    Stat_produit Sf;
    ouvriers tmpouvriers;
    conges tmpconges;
    MainWindow *window;
    Materiel tmpmateriel;
    Maintien tmpmaintien;
    Statistique2 tmpstatistique2;
    Agent tmpagent;

};
#endif // MAINWINDOW_H

