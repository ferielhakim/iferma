#include "maintien.h"
#include <QDebug>
#include <QSqlRecord>

using namespace std;
Maintien::Maintien()
{

}

Maintien::Maintien(int materielId,int agentId, int Id, QDate date, int cout)
{
    this->Id=Id;
    this->agentId=agentId;
    this->materielId=materielId;
    this->date=date;
    this->cout=cout;
}

bool Maintien::ajouter(){

    QSqlQuery query;
    QString aid= QString::number(agentId);
    QString mid= QString::number(materielId);
    QString cou= QString::number(cout);
    QString id= QString::number(Id);

    query.prepare("INSERT INTO maintien (ID, AGENT_ID, MATéRIEL_ID, H_DATE, COUT) "
                  "VALUES (:id, :aid, :mid, :date, :cou)");
    query.bindValue(":aid", aid);
    query.bindValue(":mid", mid);
    query.bindValue(":cou", cou);
    query.bindValue(":date",date);
    query.bindValue(":id", id);


    qDebug() <<"aid:  " << aid;
    qDebug() <<"mid:  " << mid;
    qDebug() <<"id:  " << id;
    qDebug() <<"cou:  " << cou;
    qDebug() <<"date:  " << date;

    return    query.exec();
}

QSqlQueryModel * Maintien::afficher_id()

{
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select ID from maintien");
   //pour afficher les ids sélectionnées à partir de la requête et résultant dans model.

    return model;
}

QSqlQueryModel * Maintien::afficher()
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select m.ID as ID, AGENT_ID,NOM, MATéRIEL_ID, H_DATE, COUT from maintien m , agent a where a.ID = m.AGENT_ID");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("AGENT_ID"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOM_Agent"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("MATERIEL_ID"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("H_DATE"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("COUT"));

    return model;
}

QSqlQueryModel * Maintien::afficher(QDate date1, QDate date2)
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select m.ID as ID, AGENT_ID, NOM , MATéRIEL_ID, H_DATE, COUT from maintien m , agent a where m.AGENT_ID = a.ID and H_DATE>= '" + date1.toString() + "' and H_DATE<= '" + date2.toString() +"'");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("AGENT_ID"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOM Agent"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("MATERIEL_ID"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("H_DATE"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("COUT"));

    return model;
}

bool Maintien::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from maintien where ID = :id");
query.bindValue(":id", res);
return    query.exec();
}

bool Maintien::modifier(){
    QSqlQuery query;
    QString id_res= QString::number(Id);
    query.prepare("UPDATE Maintien SET MATéRIEL_ID = :materielId, agent_Id=:agentId, cout=:cout, h_date=:date where ID = :id");
    query.bindValue(":id", id_res);
    query.bindValue(":materielId", materielId);
    query.bindValue(":agentId", agentId);
    query.bindValue(":cout", cout);
    query.bindValue(":date", date);
    return    query.exec();
}


