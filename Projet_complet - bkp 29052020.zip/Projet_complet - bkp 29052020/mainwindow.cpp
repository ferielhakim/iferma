#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "animaux.h"
#include "connexion.h"
#include "fiche_suivi.h"
#include "stat.h"
#include "veterinaire.h"
#include "stat_suivi.h"
#include "conges.h"
#include "ouvriers.h"
#include "notification.h"
#include "achat.h"
#include "vente.h"
#include "stats.h"
#include "client.h"
#include "fournisseur.h"
#include "produit.h"
#include "stat_produit.h"
#include "maintien.h"
#include "Agent.h"
#include "Materiel.h"
#include <QApplication>
#include <QDate>
#include <QString>
#include <QDateEdit>
#include <QDebug>
#include <QMessageBox>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QComboBox>
#include <QtPrintSupport>
#include <QPrintDialog>
#include <QVBoxLayout>
#include <QLCDNumber>
#include <QSqlQuery>
#include <QDebug>
#include <QDateTime>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include <QSqlRecord>
#include <QThread>
#include <QSqlRecord>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLineSeries>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QValueAxis>
#include <QStandardItemModel>
#include <QtCharts>
#include <QChartView>
#include <QPieSeries>
#include <QPieSlice>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tab_animaux->setModel(tmp_animal.afficher());
    ui->tab_fiche->setModel(tmp_fiche.afficher_fiche());
    ui->tab_vet->setModel(tmp_vet.afficher_vet());
    ui->tabouvriers->setModel(tmpouvriers.afficher());
    ui->tabconges->setModel(tmpconges.afficherC());
    ui->lineEdit->setValidator(new QIntValidator(0,99999999,this));
    ui->lineEdit_2->setInputMask("aaaaaaaaaa");
    ui->lineEdit_3->setInputMask("aaaaaaaaaa");
    ui->lineEdit_4->setValidator(new QIntValidator(0,65,this));
    ui->lineEdit_5->setValidator(new QIntValidator(20000000,99999999,this));
    ui->lineEdit_6->setInputMask("aaaaaaaaaaaaaaaaa");
    ui->lineEdit_7->setValidator(new QIntValidator(0,5000,this));
    ui->lineEdit_8->setValidator(new QIntValidator(0,30,this));
    ui->lineEdit_11->setValidator(new QIntValidator(0,99999999,this));
    ui->lineEdit_12->setValidator(new QIntValidator(0,99999999,this));
    ui->lineEdit_13->setInputMask("aaaaaaaaaa");
    ui->lineEdit_14->setValidator(new QIntValidator(1,30,this));

    /*ui->tab_affM->setModel(tmpmateriel.afficher());
    ui->tab_affMa->setModel(tmpmaintien.afficher());
    ui->tab_affM_2->setModel(tmpagent.afficher());*/
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::display_listes()
{
    //initialiser tabs
    ui->tab_animaux->setModel(tmp_animal.afficher());
    ui->tab_fiche->setModel(tmp_fiche.afficher_fiche());
    ui->tab_vet->setModel(tmp_vet.afficher_vet());
    //initaliser combo_box
    ui->id_aff_2->setModel(tmp_animal.afficher_id());
    ui->id_supp->setModel(tmp_animal.afficher_id());
    ui->id_modif->setModel(tmp_animal.afficher_id());
    ui->id_modif_2->setModel(tmp_animal.afficher_id());
    ui->mat_modif->setModel(tmp_vet.afficher_matricule());
    ui->mat_vet_supp->setModel(tmp_vet.afficher_matricule());
    ui->veterinaire->setModel(tmp_vet.afficher_matricule());
    ui->vet->setModel(tmp_vet.afficher_matricule());
    ui->num_supp->setModel(tmp_fiche.afficher_num_fiche());
    ui->num_modif->setModel(tmp_fiche.afficher_num_fiche());
    //initaliser stat
    mainLayout=new QVBoxLayout;
    mainLayout->addWidget(s.Preparechart());
    ui->stat_animaux->setLayout(mainLayout);
    mainLayout2=new QVBoxLayout;
    mainLayout2->addWidget(s2.Preparechart());
    ui->stat_fiche->setLayout(mainLayout2);

    ui->tab_affM->setModel(tmpmateriel.afficher());
    ui->tab_affMa->setModel(tmpmaintien.afficher());
    ui->tab_affM_2->setModel(tmpagent.afficher());
    ui->lineEdit_id_2->setModel(tmpmaintien.afficher_id());
    ui->lineEdit_id_10->setModel(tmpmaintien.afficher_id());
    ui->lineEdit_id_5->setModel(tmpmateriel.afficher_id());
    ui->lineEdit_id->setModel(tmpmateriel.afficher_id());
    ui->lineEdit_agId_2->setModel(tmpagent.afficher_id());
    ui->lineEdit_agId->setModel(tmpagent.afficher_id());
    ui->lineEdit_matId_2->setModel(tmpmateriel.afficher_id());
    ui->lineEdit_matId->setModel(tmpmateriel.afficher_id());
    ui->lineEdit_Ag_Id_Mod->setModel(tmpagent.afficher_id());
    ui->lineEdit_Ag_Id_Supp->setModel(tmpagent.afficher_id());
}

void MainWindow::refresh_stat_animaux()
{
    if ( ui->stat_animaux->layout() != NULL )
    {
    QLayoutItem* item;
    while ( ( item = ui->stat_animaux->layout()->takeAt( 0 ) ) != NULL )
    {
    delete item->widget();
    delete item;
    }
    delete ui->stat_animaux->layout();
    }
    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(s.Preparechart());
    ui->stat_animaux->setLayout(mainLayout);
}

void MainWindow::refresh_stat_fiche()
{
    if ( ui->stat_fiche->layout() != NULL )
    {
    QLayoutItem* item;
    while ( ( item = ui->stat_fiche->layout()->takeAt( 0 ) ) != NULL )
    {
    delete item->widget();
    delete item;
    }
    delete ui->stat_fiche->layout();
    }
    mainLayout2 = new QVBoxLayout;
    mainLayout2->addWidget(s2.Preparechart());
    ui->stat_fiche->setLayout(mainLayout2);
}

void MainWindow::on_ajouter_animal_clicked()
{
    int Id_animal= ui->id->text().toInt();
    QString nom= ui->nom->text();
    bool sexe= ui->sexe->currentIndex();
    QString race= ui->race->text();
    int etat= ui->etat->currentIndex();
    QDate date_naissance= ui->date->date();

  animaux a(Id_animal,nom,sexe,race,etat,date_naissance);

  if ((Id_animal<9999) && (nom!="") && (race!="") )
  {

  bool test=a.ajouter();
  if(test)
    {
      //refresh
      refresh_stat_animaux();
      ui->id_aff_2->setModel(tmp_animal.afficher_id());
      ui->id_supp->setModel(tmp_animal.afficher_id());
      ui->id_modif->setModel(tmp_animal.afficher_id());
      ui->id_modif_2->setModel(tmp_animal.afficher_id());
      ui->tab_animaux->setModel(tmp_animal.afficher());
        QMessageBox::information(nullptr, QObject::tr("Ajouter un animal"),
                  QObject::tr("Animal ajouté.\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
   else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un animal"),
                  QObject::tr("Erreur! Identifiant existe déjà\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);
  }
  else
       {
            QMessageBox::critical(nullptr, QObject::tr("Ajouter un animal"),
                QObject::tr("Erreur! Veuillez vérifier les champs\n"
                            "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

       }


}

void MainWindow::on_modif_animal_clicked()
{
    int id=ui->id_modif->currentText().toInt();;
    QString nom= ui->nom_modif->text();
    bool sexe= ui->sexe_modif->currentIndex();
    QString race= ui->race_modif->text();
    bool etat= ui->etat_modif->currentIndex();
    QDate date_naissance= ui->date_modif->date();

  animaux a(id,nom,sexe,race,etat,date_naissance);
  bool test=a.modifier(id);
  if(test)
  {
      refresh_stat_animaux();
      ui->tab_animaux->setModel(a.afficher());
      QMessageBox::information(nullptr, QObject::tr("Modifier un animal"),
                  QObject::tr("Animal modifié.\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);
  }
  else
        {
     QMessageBox::critical(nullptr, QObject::tr("Modifier un animal"),
                 QObject::tr("Erreur!\n"
                             "Erreur de modification de l'animal.\n Veuillez réessayer."), QMessageBox::Ok);
        }
}

void MainWindow::on_supprimer_animal_clicked()
{
    int idd=ui->id_supp->currentText().toInt();
    bool test= tmp_animal.supprimer(idd);
    if(test)
    {
        refresh_stat_animaux();
        ui->id_aff_2->setModel(tmp_animal.afficher_id());
        ui->id_supp->setModel(tmp_animal.afficher_id());
        ui->id_modif->setModel(tmp_animal.afficher_id());
        ui->id_modif_2->setModel(tmp_animal.afficher_id());
        ui->tab_animaux->setModel(tmp_animal.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un animal"),
                    QObject::tr("Animal supprimé.\n"
                                "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un animal"),
                    QObject::tr("Erreur !.\n"
                                "L'animal est rattaché à une fiche de suivi."), QMessageBox::Ok);
    }
}

void MainWindow::on_rech_an_textChanged(const QString &arg)
{
    int id = arg.toInt();
    ui->tab_animaux->setModel(tmp_animal.recherche_id(id));

}

void MainWindow::on_ajouter_fiche_clicked()
{
    int num_fiche= ui->num_fiche->text().toInt();
    QString analyses= ui->analyses->toPlainText();
    QString diagnostic= ui->diagnostic->toPlainText();
    float poids= ui->poids->value() ;
    float taille= ui->taille->value();
    int mat_vet=ui->veterinaire->currentText().toInt();
    QDate date_consultation= ui->date_cons->date();
    int Id_animal=ui->id_aff_2->currentText().toInt();
    Fiche_suivi f(num_fiche,analyses,diagnostic,poids,taille,date_consultation,Id_animal,mat_vet);
  if ((num_fiche<9999) && (analyses!="") && (diagnostic!="") && (poids!=0) && (taille!=0) && (Id_animal!=0) && (mat_vet!=0))
  {bool test=f.ajouter_fiche();
  if(test)
    {

      QSqlQuery query1,query2;
      int nb_an=0;
      QString res=QString::number(mat_vet);
      query2.prepare("SELECT ANIMAUX_A_TRAITER FROM VETERINAIRE WHERE MATRICULE_VET =:mat_vet");
      query2.bindValue(":mat_vet",res);
        if(query2.exec())
        {
            while(query2.next())
            {
                nb_an=query2.value(0).toInt();
            }
        nb_an=nb_an+1;
        QString res2=QString::number(nb_an);
        query1.prepare("UPDATE VETERINAIRE SET ANIMAUX_A_TRAITER=:nb_an WHERE MATRICULE_VET =:mat_vet");
        query1.bindValue(":mat_vet",res);
        query1.bindValue(":nb_an",res2);

            query1.exec();
        }
        QString okd="";
        notification ok;
        ok.notification_fiche_suivi(okd);
        //refresh
      refresh_stat_fiche();
      ui->tab_vet->setModel(tmp_vet.afficher_vet());
      ui->num_supp->setModel(tmp_fiche.afficher_num_fiche());
      ui->num_modif->setModel(tmp_fiche.afficher_num_fiche());
      ui->veterinaire->setModel(tmp_vet.afficher_matricule());
      ui->tab_fiche->setModel(tmp_fiche.afficher_fiche());
        QMessageBox::information(nullptr, QObject::tr("Ajouter une fiche de suivi"),
                  QObject::tr("Fiche de suivi ajoutée.\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
   else
        {QMessageBox::critical(nullptr, QObject::tr("Ajouter une fiche de suivi"),
                  QObject::tr("Erreur! Numero fiche existe déjà\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);}
  }
  else
  {
      QMessageBox::information(nullptr, QObject::tr("Ajouter une fiche de suivi"),
                QObject::tr("Erreur! Veuillez vérifier les champs.\n"
                            "Cliquez sur Ok pour continuer."), QMessageBox::Ok);
  }
}

void MainWindow::on_modif_fiche_clicked()
{
    int num= ui->num_modif->currentText().toInt();
    QString analyses= ui->analyses_modif->toPlainText();
    QString diagnostic= ui->diagnostic_modif->toPlainText();
    float poids= ui->poids_modif->value();
    float taille= ui->taille_modif->value();
    int matricule_vet=ui->vet->currentText().toInt();
    QDate date_consultation= ui->date_cons_modif->date();
    int Id_animal=ui->id_modif_2->currentText().toInt();
    Fiche_suivi f(num,analyses,diagnostic,poids,taille,date_consultation,Id_animal,matricule_vet);
  bool test=f.modifier_fiche(num);
  if(test)
  {
      //refresh
      ui->num_supp->setModel(tmp_fiche.afficher_num_fiche());
      ui->num_modif->setModel(tmp_fiche.afficher_num_fiche());
      ui->vet->setModel(tmp_vet.afficher_matricule());
      ui->tab_fiche->setModel(tmp_fiche.afficher_fiche());
      refresh_stat_fiche();


      QMessageBox::information(nullptr, QObject::tr("Modifier une fiche de suivi"),
                  QObject::tr("Fiche de suivi modifiée.\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);
  }
  else
        {
     QMessageBox::critical(nullptr, QObject::tr("Modifier une fiche de suivi"),
                 QObject::tr("Erreur!\n"
                             "Erreur de modification de la fiche de suivi.\n Veuillez réessayer."), QMessageBox::Ok);
        }
}

void MainWindow::on_supprimer_fiche_clicked()
{
    int num=ui->num_supp->currentText().toInt();
    bool test= tmp_fiche.supprimer_fiche(num);
    if(test)
    {
        //refresh
        refresh_stat_fiche();
        ui->num_supp->setModel(tmp_fiche.afficher_num_fiche());
        ui->num_modif->setModel(tmp_fiche.afficher_num_fiche());
        ui->tab_fiche->setModel(tmp_fiche.afficher_fiche());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une fiche de suivi"),
                    QObject::tr("Fiche de suivi supprimée.\n"
                                "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Supprimer une fiche de suivi"),
                    QObject::tr("Erreur !.\n"
                                "Suppression impossible."), QMessageBox::Ok);
    }
}

void MainWindow::on_rech_fiche_textChanged(const QString &arg1)
{
    int num=arg1.toInt();
    ui->tab_fiche->setModel(tmp_fiche.recherche_num_fiche(num));
}

void MainWindow::on_trier_currentTextChanged(const QString &arg1)
{
    QString tri=arg1;
    if (tri=="ID")
    {
        ui->tab_animaux->setModel(tmp_animal.trier_id());
    }
    else
        ui->tab_animaux->setModel(tmp_animal.trier_nom());
}

void MainWindow::on_trier_fiche_currentTextChanged(const QString &arg1)
{
    QString tri=arg1;
    if (tri=="ID animal")
    {
        ui->tab_fiche->setModel(tmp_fiche.trier_id());
    }
    else
        ui->tab_fiche->setModel(tmp_fiche.trier_num());
}

void MainWindow::on_imprimer_animal_clicked()
{
    int id=ui->rech_an->text().toInt();
        QString id_animal="";
        QString nom="";
        QString sexe="";
        QString race="";
        QString date_naissance="";
        QString etat="";
        QString res=QString::number(id);
        QSqlQuery query;
        query.prepare("SELECT * FROM ANIMAUX WHERE ID_ANIMAL= :id");
        query.bindValue(":id",res);
        if (query.exec())
        {
            while (query.next())
            {
                id_animal=query.value(0).toString();
                nom=query.value(1).toString();
                sexe=query.value(2).toString();
                race=query.value(3).toString();
                date_naissance=query.value(4).toString();
                etat=query.value(5).toString();
            }
        }

        QPrinter printer(QPrinter::HighResolution);
        printer.setPageSize(QPrinter::A4);
        QPrintDialog *dialog = new QPrintDialog(&printer,this);
         if (dialog->exec() == QDialog::Accepted)
            {
                QPainter painter(&printer);
                painter.begin(&printer);
                quint32 iYPos = 0;
                quint32 iWidth = printer.width();
                quint32 iHeight = printer.height();
                QPixmap pxPic;
                pxPic.load("C:/Users/DELL/Documents/2ème/2ème semestre/c++/projet/Animaux_suivi/logo.png", "PNG");
                QSize s(iWidth/3, iHeight/5);
                QPixmap pxScaledPic = pxPic.scaled(s, Qt::KeepAspectRatio, Qt::FastTransformation);
                painter.drawPixmap(3500, iYPos, pxScaledPic.width(), pxScaledPic.height(), pxScaledPic);
                iYPos -= pxScaledPic.height() + 1000;
                QFont f;
                f.setPointSize(20);
                f.setBold(true);
                f.setItalic(true);
                painter.setBrush(QColor(50,205,50));
                painter.setFont(f);
                painter.drawText(1700,400,"Fiche animal");
                painter.drawText(400, 1000, "ID animal: ");
                painter.drawText(2000, 1000,id_animal);
                f.setPointSize(15);
                f.setBold(true);
                painter.setFont(f);
                painter.drawText(100, 1400, "Nom: ");
                painter.drawText(1000, 1400,nom);
                painter.drawText(100, 1700, "Sexe: ");
                painter.drawText(1000, 1700,sexe);
                painter.drawText(100, 2000, "Race: ");
                painter.drawText(1000, 2000,race);
                painter.drawText(100, 2300, "Date de naissance: ");
                painter.drawText(1500, 2300,date_naissance);
                painter.drawText(100, 2600, "Etat: ");
                painter.drawText(1000, 2600,etat);
                QFont f1,f2;
                f1.setPointSize(15);
                f1.setItalic(true);
                f1.setBold(true);
                f1.setUnderline(true);
                painter.setBrush(QColor(255,0,0));
                painter.setFont(f1);
                painter.drawText(3800,5000, "NB");
                f2.setPointSize(10);
                f2.setItalic(true);
                painter.setFont(f2);
                painter.drawText(3500,5200,"Etat=0 animal en bonne santé ");
                painter.drawText(3500,5400,"Etat=1 animal malade");
                painter.drawText(3500,5600,"Sexe=0 Mâle");
                painter.drawText(3500,5800,"Sexe=1 Femelle");

                   painter.end();
               }
}

void MainWindow::on_imprimer_fiche_clicked()
{
    int num=ui->rech_fiche->text().toInt();
    QString num_fiche="";
    QString analyses="";
    QString diagnostic="";
    QString poids="";
    QString taille="";
    QString date="";
    QString id_an="";
    QString mat_vet="";
    QString res=QString::number(num);
    QSqlQuery query;
    query.prepare("SELECT * FROM FICHE_SUIVI WHERE NUM_FICHE = :num");
    query.bindValue(":num",res);
    if (query.exec())
    {
        while (query.next())
        {
            num_fiche=query.value(0).toString();
            analyses=query.value(1).toString();
            diagnostic=query.value(2).toString();
            poids=query.value(3).toString();
            taille=query.value(4).toString();
            date=query.value(5).toString();
            id_an=query.value(6).toString();
            mat_vet=query.value(7).toString();
        }
    }

    QPrinter printer(QPrinter::HighResolution);
    printer.setPageSize(QPrinter::A4);
    QPrintDialog *dialog = new QPrintDialog(&printer,this);
     if (dialog->exec() == QDialog::Accepted)
        {
            QPainter painter(&printer);
            painter.begin(&printer);
            quint32 iYPos = 0;
            quint32 iWidth = printer.width();
            quint32 iHeight = printer.height();
            QPixmap pxPic;
            pxPic.load("C:/Users/DELL/Documents/2ème/2ème semestre/c++/projet/Animaux_suivi/logo.png", "PNG");
            QSize s(iWidth/3, iHeight/5);
            QPixmap pxScaledPic = pxPic.scaled(s, Qt::KeepAspectRatio, Qt::FastTransformation);
            painter.drawPixmap(3500, iYPos, pxScaledPic.width(), pxScaledPic.height(), pxScaledPic);
            iYPos += pxScaledPic.height() + 250;
            QFont f;
            f.setPointSize(20);
            f.setBold(true);
            f.setItalic(true);
            painter.setFont(f);
            painter.drawText(1500,400,"Fiche de suivi médical");
            painter.drawText(400, 1000, "Fiche de suivi numéro: ");
            painter.drawText(2500, 1000,num_fiche);
            f.setPointSize(15);
            f.setBold(true);
            painter.setFont(f);
            painter.drawText(100, 1400, "Matricule du vétérinaire: ");
            painter.drawText(1700, 1400,mat_vet);
            painter.drawText(100, 1700, "ID de l'animal: ");
            painter.drawText(1500, 1700,id_an);
            painter.drawText(100, 2000, "Analyses effectuées: ");
            painter.drawText(1500, 2000,analyses);
            painter.drawText(100, 2300, "Diagnostic: ");
            painter.drawText(1500, 2300,diagnostic);
            painter.drawText(100, 2600, "Poids de l'animal: ");
            painter.drawText(1500, 2600,poids);
            painter.drawText(100, 2900, "Taille de l'animal: ");
            painter.drawText(1500, 2900,taille);
            painter.drawText(100, 3200, "Date de la consultation: ");
            painter.drawText(1700, 3200,date);


               painter.end();

           }
}

void MainWindow::on_ajouter_vet_clicked()
{
    int matricule_vet=ui->matricule_vet->text().toInt();
    QString nom=ui->nom_vet->text();
    QString prenom=ui->prenom->text();
    int numero_telephone=ui->num_tel->text().toInt();
    QString adresse=ui->adresse->toPlainText();
    int animaux_a_traiter=ui->nb_an->value();
    Veterinaire v(matricule_vet,nom,prenom,numero_telephone,adresse,animaux_a_traiter);
    bool test=v.ajouter();
    if ((matricule_vet!=0) && (matricule_vet<99) && (prenom!="") && (nom!="") && (numero_telephone!=0) && (adresse!="") && (numero_telephone<99999999))
    {
        if (test)
    {
        ui->tab_vet->setModel(tmp_vet.afficher_vet());
        ui->mat_modif->setModel(tmp_vet.afficher_matricule());
        ui->mat_vet_supp->setModel(tmp_vet.afficher_matricule());
        ui->veterinaire->setModel(tmp_vet.afficher_matricule());
        ui->vet->setModel(tmp_vet.afficher_matricule());


        QMessageBox::information(nullptr, QObject::tr("Ajouter un vétérinaire"),
                  QObject::tr("Vétérinaire ajouté.\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
   else
        {QMessageBox::critical(nullptr, QObject::tr("Ajouter un vétérinaire"),
                  QObject::tr("Erreur! \n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);}
    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un vétérinaire"),
                          QObject::tr("Erreur! \n"
                                      "Veuillez vérifier les champs."), QMessageBox::Ok);
    }


}

void MainWindow::on_modif_vet_clicked()
{
    int id=ui->mat_modif->currentText().toInt();
    QString nom=ui->nom_vet_modif->text();
    QString prenom=ui->prenom_vet_modif->text();
    int numero_telephone=ui->num_tel_modif->text().toInt();
    QString adresse=ui->adresse_modif2->toPlainText();
    int animaux_a_traiter=ui->an_modif->value();
    Veterinaire v(id,nom,prenom,numero_telephone,adresse,animaux_a_traiter);
    bool test=v.modifier(id);
    if (test)
    {
        ui->mat_modif->setModel(tmp_vet.afficher_matricule());
        ui->mat_vet_supp->setModel(tmp_vet.afficher_matricule());
        ui->veterinaire->setModel(tmp_vet.afficher_matricule());
        ui->vet->setModel(tmp_vet.afficher_matricule());
        ui->tab_vet->setModel(tmp_vet.afficher_vet());
        QMessageBox::information(nullptr, QObject::tr("Modifier un vétérinaire"),
                  QObject::tr("Vétérinaire modifié.\n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
   else
        {QMessageBox::critical(nullptr, QObject::tr("Modifier un vétérinaire"),
                  QObject::tr("Erreur! \n"
                              "Cliquez sur Ok pour continuer."), QMessageBox::Ok);}
}

void MainWindow::on_supprimer_vet_clicked()
{
    int idd=ui->mat_vet_supp->currentText().toInt();
    bool test= tmp_vet.supprimer(idd);
    if(test)
    {
        ui->mat_modif->setModel(tmp_vet.afficher_matricule());
        ui->mat_vet_supp->setModel(tmp_vet.afficher_matricule());
        ui->veterinaire->setModel(tmp_vet.afficher_matricule());
        ui->vet->setModel(tmp_vet.afficher_matricule());
        ui->tab_vet->setModel(tmp_vet.afficher_vet());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un vétérinaire"),
                    QObject::tr("Vétérinaire supprimé.\n"
                                "Cliquez sur Ok pour continuer."), QMessageBox::Ok);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un vétérinaire"),
                    QObject::tr("Erreur ! Suppression impossible.\n"
                                "Le vétérinaire est associé à une fiche de suivi"), QMessageBox::Ok);
    }

}

void MainWindow::on_trier_vet_currentTextChanged(const QString &arg1)
{
    QString tri=arg1;
    if (tri=="Nom")
        ui->tab_vet->setModel(tmp_vet.trier_nom());
    else if (tri=="Prenom")
        ui->tab_vet->setModel(tmp_vet.trier_prenom());
    else if(tri=="Matricule")
        ui->tab_vet->setModel(tmp_vet.trier_matricule());
}

void MainWindow::on_rech_vet_textChanged(const QString &arg2)
{
    int mat=arg2.toInt();
    ui->tab_vet->setModel(tmp_vet.recherche_matricule(mat));
}

void MainWindow::on_imprimer_vet_clicked()
{
    int matricule=ui->rech_vet->text().toInt();
    QString matricule_vet="";
    QString nom="";
    QString prenom="";
    QString numero_telephone="";
    QString adresse="";
    QString animaux_a_traiter="";
    QString res=QString::number(matricule);
    QSqlQuery query;
    query.prepare("SELECT * FROM VETERINAIRE WHERE MATRICULE_VET = :matricule");
    query.bindValue(":matricule",res);
    if (query.exec())
    {
        while (query.next())
        {
            matricule_vet=query.value(0).toString();
            nom=query.value(1).toString();
            prenom=query.value(2).toString();
            numero_telephone=query.value(3).toString();
            adresse=query.value(4).toString();
            animaux_a_traiter=query.value(5).toString();
        }
    }

    QPrinter printer(QPrinter::HighResolution);
    printer.setPageSize(QPrinter::A4);
    QPrintDialog *dialog = new QPrintDialog(&printer,this);
     if (dialog->exec() == QDialog::Accepted)
        {
            QPainter painter(&printer);
            painter.begin(&printer);
            quint32 iYPos = 0;
            quint32 iWidth = printer.width();
            quint32 iHeight = printer.height();
            QPixmap pxPic;
            pxPic.load("C:/Users/DELL/Documents/2ème/2ème semestre/c++/projet/Animaux_suivi/logo.png", "PNG");
            QSize s(iWidth/3, iHeight/5);
            QPixmap pxScaledPic = pxPic.scaled(s, Qt::KeepAspectRatio, Qt::FastTransformation);
            painter.drawPixmap(3500, iYPos, pxScaledPic.width(), pxScaledPic.height(), pxScaledPic);
            iYPos += pxScaledPic.height() + 250;
            QFont f;
            f.setPointSize(20);
            f.setBold(true);
            f.setItalic(true);
            painter.setFont(f);
            painter.drawText(1700,400,"Fiche vétérinaire");
            painter.drawText(400, 1000, "Matricule vétérinaire: ");
            painter.drawText(2500, 1000,matricule_vet);
            f.setPointSize(15);
            f.setBold(true);
            painter.setFont(f);
            painter.drawText(100, 1400, "Nom: ");
            painter.drawText(1500, 1400,nom);
            painter.drawText(100, 1700, "Prenom: ");
            painter.drawText(1500, 1700,prenom);
            painter.drawText(100, 2000, "Numéro de téléphone: ");
            painter.drawText(1800, 2000,numero_telephone);
            painter.drawText(100, 2300, "Adresse: ");
            painter.drawText(1500, 2300,adresse);
            painter.drawText(100, 2600, "Nombre d'animaux à traiter: ");
            painter.drawText(2000, 2600,animaux_a_traiter);

               painter.end();

           }
}

void MainWindow::on_pb_AjouterOuv_clicked()
{
    int id = ui->lineEdit->text().toInt();
    QString nom= ui->lineEdit_2->text();
    QString prenom= ui->lineEdit_3->text();
    int age= ui->lineEdit_4->text().toInt();
    int numTel= ui->lineEdit_5->text().toInt();
    QString fonction= ui->lineEdit_6->text();
    int salaireM= ui->lineEdit_7->text().toInt();
    int HTS= ui->lineEdit_8->text().toInt();
    int congeA= ui->lineEdit_9->text().toInt();
    int primeA= ui->lineEdit_10->text().toInt();
    if(id!=0)
    {
        ouvriers ouv(id,nom,prenom,age,numTel,fonction,salaireM,HTS,congeA,primeA);
        bool test=ouv.ajouter();
        if(test)
            {
                ui->tabouvriers->setModel(tmpouvriers.afficher());//refresh
                 QMessageBox::information(nullptr, QObject::tr("Ajouter un ouvrier"),
                  QObject::tr("ouvrier ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
                QString okd="";
                notification ok;
                ok.notification_ajouterOuv(okd);
            }
        else
                QMessageBox::critical(nullptr, QObject::tr("Ajouter un ouvrier"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
           }

    else
        QMessageBox::critical(nullptr, QObject::tr("ajouter un ouvrier"),
                    QObject::tr("Erreur !.\n"
                                "Veuillez saisir un identifiant pour ajouter un ouvrier .\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pb_SupprimerOuv_clicked()
{
    int id = ui->lineEdit_19->text().toInt();
    bool test=tmpouvriers.supprimer(id);
    if(test)
    {ui->tabouvriers->setModel(tmpouvriers.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un ouvrier"),
                    QObject::tr("ouvrier supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un ouvrier"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pb_ok1_clicked()
{
    QString iid=ui->lineEdit_18->text();
   ui->tabouvriers->setModel(tmpouvriers.chercher(iid));
}

void MainWindow::on_tabouvriers_activated(const QModelIndex &index)
{
    QString var=ui->tabouvriers->model()->data(index).toString();
    QSqlQuery query1;
    query1.prepare("select * from ouvriers where ID_OUV=:idOuv");
    query1.bindValue(":idOuv", var);

    if (query1.exec())
    {

        while (query1.next()) {

             ui->lineEdit_19->setText(query1.value(0).toString());//supprimer
             ui->lineEdit_12->setText(query1.value(0).toString());//ajoutCongés
             ui->lineEdit_13->setText(query1.value(1).toString());//ajoutCongés

             ui->lineEdit_21->setText(query1.value(0).toString());
             ui->lineEdit_22->setText(query1.value(1).toString());
             ui->lineEdit_23->setText(query1.value(2).toString());
             ui->lineEdit_24->setText(query1.value(3).toString());
             ui->lineEdit_25->setText(query1.value(4).toString());
             ui->lineEdit_26->setText(query1.value(5).toString());
             ui->lineEdit_27->setText(query1.value(6).toString());
             ui->lineEdit_28->setText(query1.value(7).toString());
             ui->lineEdit_29->setText(query1.value(8).toString());
             ui->lineEdit_30->setText(query1.value(9).toString());

        }
    }
}

void MainWindow::on_pb_ModifierOuv_clicked()
{
    int id = ui->lineEdit_21->text().toInt();
    QString nom= ui->lineEdit_22->text();
    QString prenom= ui->lineEdit_23->text();
    int age= ui->lineEdit_24->text().toInt();
    int numTel= ui->lineEdit_25->text().toInt();
    QString fonction= ui->lineEdit_26->text();
    int salaireM= ui->lineEdit_27->text().toInt();
    int HTS= ui->lineEdit_28->text().toInt();
    int congeA= ui->lineEdit_29->text().toInt();
    int primeA= ui->lineEdit_30->text().toInt();
    if(id!=0)
    {
        ouvriers ouv(id,nom,prenom,age,numTel,fonction,salaireM,HTS,congeA,primeA);
         bool test=ouv.modifier(id);
         if(test)
       {ui->tabouvriers->setModel(tmpouvriers.afficher());//refresh
       QMessageBox::information(nullptr, QObject::tr("Modifier un ouvriers"),
                         QObject::tr("ouvrier modifié.\n"
                                     "Click Cancel to exit."), QMessageBox::Cancel);

       }
         else
             QMessageBox::critical(nullptr, QObject::tr("Modifier un ouvriers"),
                         QObject::tr("Erreur !.\n"
                                     "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Modifier un ouvrier"),
                    QObject::tr("Erreur !.\n"
                                "Veuillez saisir un idOuv pour modifier un ouvrier .\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_comboBox_activated(const QString &arg1)
{
    QString var=arg1;
    if(var=="Salaire")
    {
        ui->tabouvriers->setModel(tmpouvriers.afficher2());
    }
    else if(var=="Age")
    {
         ui->tabouvriers->setModel(tmpouvriers.afficher3());
    }
    else if(var=="HTS")
    {
         ui->tabouvriers->setModel(tmpouvriers.afficher4());
    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Modifier un ouvriers"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }

}

void MainWindow::on_pb_AjouterCon_clicked()
{

    int idCon = ui->lineEdit_11->text().toInt();
     int idOuv = ui->lineEdit_12->text().toInt();
    QString nomOuv= ui->lineEdit_13->text();
    int duree= ui->lineEdit_14->text().toInt();
    QDate dateDebut= ui->dateEdit_2->date();
      QString p_nonp= ui->comboBox_3->currentText();
      int verif;

    if((idCon!=0) && (idOuv!=0) && (nomOuv!=""))
    {

        conges con(idCon,idOuv,nomOuv,duree,dateDebut,p_nonp);
        verif=con.chercherCon(idOuv,dateDebut);
        if(verif==0)
        {


        bool test=con.ajouterC();
        if(test)
      {ui->tabconges->setModel(tmpconges.afficherC());//refresh tab congé
            ui->tabouvriers->setModel(tmpouvriers.afficher());
            QString okd="";
                              notification ok;
                              ok.notification_ajouterCon(okd);
      QMessageBox::information(nullptr, QObject::tr("Ajouter un conge"),
                        QObject::tr("Congé ajouté.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

      }
        else
            QMessageBox::critical(nullptr, QObject::tr("Ajouter un conges"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
         }
        else
        {
            QString okd="";
                              notification ok;
                              ok.notification_memeDate(okd);
        }
    }
        else
            QMessageBox::critical(nullptr, QObject::tr("ajouter un congé"),
                        QObject::tr("Erreur !.\n"
                                    "Veuillez saisir un idCon, idOuv et nomOuv  pour ajouter un congés .\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pb_SupprimerCon_clicked()
{
    int id = ui->lineEdit_20->text().toInt();

    if(id!=0){
      bool test=tmpconges.supprimerC(id);
      if(test)
      {ui->tabconges->setModel(tmpconges.afficherC());//refresh
          QMessageBox::information(nullptr, QObject::tr("Supprimer un conge"),
                      QObject::tr("conge supprimé.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);

      }
      else
          QMessageBox::critical(nullptr, QObject::tr("Supprimer un conge"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("supprimer un congé"),
                    QObject::tr("Erreur !.\n"
                                "Veuillez saisir un idCon pour supprimer un congés .\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);



}

void MainWindow::on_pb_ok2_clicked()
{
    QString iid=ui->lineEdit_17->text();
   ui->tabconges->setModel(tmpconges.chercherC(iid));
}

void MainWindow::on_tabconges_activated(const QModelIndex &index)
{
    QString var=ui->tabconges->model()->data(index).toString();
    QSqlQuery query1;
    query1.prepare("select * from CONGES where ID_CON=:idCon");
    query1.bindValue(":idCon", var);

    if (query1.exec())
    {

        while (query1.next()) {

            ui->lineEdit_15->setText(query1.value(0).toString());//imprimer
            ui->lineEdit_20->setText(query1.value(0).toString());//supprimer

             ui->lineEdit_31->setText(query1.value(0).toString());
             ui->lineEdit_32->setText(query1.value(1).toString());
             ui->lineEdit_33->setText(query1.value(2).toString());
             ui->lineEdit_34->setText(query1.value(3).toString());
             ui->dateEdit->setDate(query1.value(4).toDate());
             ui->comboBox_4->setCurrentText(query1.value(5).toString());

        }
    }
}

void MainWindow::on_pb_ModifierCon_clicked()
{
    int idCon = ui->lineEdit_31->text().toInt();
     int idOuv = ui->lineEdit_32->text().toInt();
    QString nomOuv= ui->lineEdit_33->text();
    int duree= ui->lineEdit_34->text().toInt();
    QDate dateDebut= ui->dateEdit->date();
    QString p_nonp= ui->comboBox_4->currentText();
    if(idCon!=0){
        conges con(idCon,idOuv,nomOuv,duree,dateDebut,p_nonp);
        bool test=con.modifierC(idCon);
       if(test)
     {ui->tabconges->setModel(tmpconges.afficherC());//refresh
     QMessageBox::information(nullptr, QObject::tr("Modifier un conge"),
                       QObject::tr("congé modifié.\n"
                                   "Click Cancel to exit."), QMessageBox::Cancel);

     }
       else
           QMessageBox::critical(nullptr, QObject::tr("Modifier un conge"),
                       QObject::tr("Erreur !.\n"
                                   "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier un congé"),
                    QObject::tr("Erreur !.\n"
                                "Veuillez saisir un idCon pour modifier un congés .\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);



}

void MainWindow::on_pushButton_clicked()
{
    QString num1 = ui->lineEdit_15->text();
        int num = ui->lineEdit_15->text().toInt();

        QSqlQuery query1;

        QString idCon="";
        QString idOuv="";
        QString nomOuv="";
        QString duree="";
        QDate dateDebut;
        QString dateDebut1="";
        QString p_nonp="";

        if(num1!=""){
        query1.prepare("select * from CONGES where ID_CON=:id");
       query1.bindValue(":id", num);

        if (query1.exec())
        {
          int a=0;
            while (query1.next()) {

                 idCon= query1.value(0).toString();
                 idOuv= query1.value(1).toString();
                 nomOuv= query1.value(2).toString();
                 duree= query1.value(3).toString();
                 dateDebut = query1.value(4).toDate();
                 dateDebut1=dateDebut.toString("dd-MM-yyyy");
                 p_nonp= query1.value(5).toString();

                 a++;

            }
            qDebug()<<a;
        }
              QPrinter printer(QPrinter::HighResolution);
                  printer.setPageSize(QPrinter::A4);

                 QPrintDialog *dialog = new QPrintDialog(&printer);
                  if (dialog->exec() == QDialog::Accepted)
                  {               QPainter painter(&printer);
                                  painter.begin(&printer);
                                  QFont f;
                                      f.setPointSize(20);
                                      f.setBold(true);
                                      painter.setFont(f);
                                   painter.drawText(100, 500, "Conge N°:");
                                    painter.drawText(2000, 500, idCon);
                                   f.setPointSize(15);
                                   f.setBold(true);
                                   painter.setFont(f);
                                   painter.drawText(100, 1000, "Id conge:");
                                   painter.drawText(1000, 1000,idCon);
                                   painter.drawText(100, 1200, "Id ouvrier:");
                                   painter.drawText(1200, 1200,idOuv);
                                   painter.drawText(100, 1400, "Nom ouvrier:");
                                   painter.drawText(1500, 1400,nomOuv);
                                   painter.drawText(100, 1600, " duree:");
                                   painter.drawText(1500, 1600,duree);
                                   painter.drawText(100, 1800, "Date debut:");
                                   painter.drawText(1500, 1800,dateDebut1);
                                   painter.drawText(100, 2000, "Payé/Non Payé :");
                                   painter.drawText(1500, 2000,p_nonp);

                                  painter.end();

                  }}
        else
            QMessageBox::critical(nullptr, QObject::tr("Imprimer un conge"),
                        QObject::tr("Erreur !.\n"
                                    "Veuillez selectionner un conge à imprimer .\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_comboBox_2_activated(const QString &arg1)
{
    QString var=arg1;
    if(var=="Duree")
    {
        ui->tabconges->setModel(tmpconges.afficherC1());
    }
    else if(var=="Identifiant")
    {
         ui->tabconges->setModel(tmpconges.afficherC());
    }

    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Modifier un conges"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    QSqlQuery query,query1;
    QString p="Paye";
    QString p1="NonPaye";
    QDate dateD,dateD1;
    int a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0,a11=0,a12=0;
    int b1=0,b2=0,b3=0,b4=0,b5=0,b6=0,b7=0,b8=0,b9=0,b10=0,b11=0,b12=0;
    query.prepare("select DATE_D from CONGES where P_NONP=:p");
    query.bindValue(":p",p);
    if (query.exec())
    {
        while (query.next()) {

                               dateD = query.value(0).toDate();
                               if(dateD.month()==01)
                                   a1++;
                               else if(dateD.month()==02)
                                   a2++;
                               else if(dateD.month()==03)
                                   a3++;
                               else if(dateD.month()==04)
                                   a4++;
                               else if(dateD.month()==05)
                                   a5++;
                               else if(dateD.month()==06)
                                   a6++;
                               else if(dateD.month()==07)
                                   a7++;
                               else if(dateD.month()==8)
                                   a8++;
                               else if(dateD.month()==9)
                                   a9++;
                               else if(dateD.month()==10)
                                   a10++;
                               else if(dateD.month()==11)
                                   a11++;
                               else if(dateD.month()==12)
                                   a12++;
                             }
    }
    query1.prepare("select DATE_D from CONGES where P_NONP=:p1");
    query1.bindValue(":p1",p1);
    if (query1.exec())
    {
        while (query1.next()) {

                               dateD1 = query1.value(0).toDate();
                               if(dateD1.month()==01)
                                   b1++;
                               else if(dateD1.month()==02)
                                   b2++;
                               else if(dateD1.month()==03)
                                   b3++;
                               else if(dateD1.month()==04)
                                   b4++;
                               else if(dateD1.month()==05)
                                   b5++;
                               else if(dateD1.month()==06)
                                   b6++;
                               else if(dateD1.month()==07)
                                   b7++;
                               else if(dateD1.month()==8)
                                   b8++;
                               else if(dateD1.month()==9)
                                   b9++;
                               else if(dateD1.month()==10)
                                   b10++;
                               else if(dateD1.month()==11)
                                   b11++;
                               else if(dateD1.month()==12)
                                   b12++;
                             }
    }
   //![1]
        QBarSet *set0 = new QBarSet("Congé Payé");
        QBarSet *set1 = new QBarSet("Congé non Payé");
        *set0 << a1 << a2 << a3 << a4 << a5 << a6 << a7 << a8 << a9 << a10 << a11 << a12;
        *set1 << b1 << b2 << b3 << b4 << b5 << b6 << b7 << b8 << b9 << b10 << b11 << b12;
    //![2]
        QBarSeries *series = new QBarSeries();
        series->append(set0);
        series->append(set1);
    //![3]
        QChart *chart = new QChart();
        chart->addSeries(series);
        chart->setTitle("Les Statistique des Congés");
        chart->setAnimationOptions(QChart::SeriesAnimations);
    //![4]
        QStringList categories;
        categories << "Jan" << "Feb" << "Mar" << "Apr" << "May" << "Jun" << "Juil" << "Aout" << "Sept" << "Oct" << "Nov" << "Dec";
        QBarCategoryAxis *axis = new QBarCategoryAxis();
        axis->append(categories);
        chart->createDefaultAxes();
        chart->setAxisX(axis, series);
    //![5]
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignBottom);
    //![6]
        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);
    //![7]
       window= new MainWindow(this);
        window->setCentralWidget(chartView);
        window->resize(420, 300);
        window->show();
}

void MainWindow::on_mat_modif_currentTextChanged(const QString &arg1)
{

    int mat=arg1.toInt();
    QString res=QString::number(mat);
    QSqlQuery query;
    query.prepare("SELECT * FROM VETERINAIRE WHERE MATRICULE_VET=:mat");
    query.bindValue(":mat",res);
    if (query.exec())
    {
        while(query.next())
        {
            ui->nom_vet_modif->setText(query.value(1).toString());
            ui->prenom_vet_modif->setText(query.value(2).toString());
            ui->num_tel_modif->setText(query.value(3).toString());
            ui->adresse_modif2->setText(query.value(4).toString());
            ui->an_modif->setValue(query.value(5).toInt());

        }
    }
}

void MainWindow::on_num_modif_currentTextChanged(const QString &arg1)
{
    int num=arg1.toInt();
    QString res=QString::number(num);
    QSqlQuery query;
    query.prepare("SELECT * FROM FICHE_SUIVI WHERE NUM_FICHE=:num");
    query.bindValue(":num",res);
    if (query.exec())
    {
        while(query.next())
        {
            ui->analyses_modif->setText(query.value(1).toString());
            ui->diagnostic_modif->setText(query.value(2).toString());
            ui->poids_modif->setValue(query.value(3).toDouble());
            ui->taille_modif->setValue(query.value(4).toDouble());
            ui->date_cons_modif->setDate(query.value(5).toDate());
            ui->id_modif_2->setCurrentText(query.value(6).toString());
            ui->vet->setCurrentText(query.value(7).toString());
        }
    }
}

void MainWindow::on_id_modif_currentTextChanged(const QString &arg1)
{
    int id=arg1.toInt();
    QString res=QString::number(id);
    QSqlQuery query;
    query.prepare("SELECT * FROM ANIMAUX WHERE ID_ANIMAL=:id");
    query.bindValue(":id",res);
    if (query.exec())
    {
        while(query.next())
        {
            ui->nom_modif->setText(query.value(1).toString());
            if (query.value(2)==0)
            {
                ui->sexe_modif->setCurrentIndex(0) ;
            }
            else
            {
                ui->sexe_modif->setCurrentIndex(1);
            }
            ui->race_modif->setText(query.value(3).toString());
            ui->date_modif->setDate(query.value(4).toDate());

            if (query.value(5).toInt()==0)
            {
                ui->etat_modif->setCurrentIndex(0);
            }
            else
            {
                ui->etat_modif->setCurrentIndex(1);
            }
        }
    }
}

void MainWindow::display_commandes()
{
    ui->ajouter_id->setModel(tmpachat.afficherid());
    ui->supprimer_id->setModel(tmpachat.afficher1());
    ui->modifier_id->setModel(tmpachat.afficher1());
    ui->chercher_id->setModel(tmpachat.afficher1());

    ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
    ui->supprimer_matricule->setModel(tmpvente.afficher2());
    ui->modifier_matricule->setModel(tmpvente.afficher2());
    ui->chercher_matricule->setModel(tmpvente.afficher2());
    ui->tableView_achat->setModel(tmpachat.afficher());
    ui->tableView_vente->setModel(tmpvente.afficherV());
    ui->tabclient->setModel(tmpclient.afficher());
    //CONTROLE DE SAISIE
    ui->ajouter_prix->setValidator(new QIntValidator(0,99999,this));
    ui->ajouter_quantite->setValidator(new QIntValidator(0,99999,this));
    ui->modifier_prix->setValidator(new QIntValidator(0,99999,this));
    ui->modifier_quantite->setValidator(new QIntValidator(0,99999,this));
    ui->ajouter_quantiteV->setValidator(new QIntValidator(0,99999,this));
    ui->ajouter_prixV->setValidator(new QIntValidator(0,99999,this));
    ui->modifier_quantiteV->setValidator(new QIntValidator(0,99999,this));
    ui->modifier_prixV->setValidator(new QIntValidator(0,99999,this));
    ui->lineEdit_cin->setValidator(new QIntValidator(0,999999,this));

    mainLayout=new QVBoxLayout;
        mainLayout->addWidget(s1.Preparechart());
        ui->stat_2->setLayout(mainLayout);
}
void MainWindow::display_list_client_fournisseur_produit()
{
    //initialiser tab_client et tab_partenaire
    ui->tabclient->setModel(tmpclient.afficher());
    ui->tabproduit->setModel(tmpproduit.afficher());
    ui->tabfournisseur->setModel(tmpfournisseur.afficher());
    //initaliser stat
    mainLayout=new QVBoxLayout;
    mainLayout->addWidget(Sf.Preparechart());
    ui->widget_stat->setLayout(mainLayout);
    //initaliser combo_box
    ui->comboCINsupp->setModel(tmpclient.combo_box());
    ui->comboCINmodif->setModel(tmpclient.combo_box());
    ui->comboFsupp->setModel(tmpfournisseur.combo_box());
    ui->comboFmodif->setModel(tmpfournisseur.combo_box());
    ui->comboPsupp->setModel(tmpproduit.combo_box());
    ui->comboPmodif->setModel(tmpproduit.combo_box());
    ui->comboBox_m->setModel(tmpclient.combo_box());
    ui->comboBox_f->setModel(tmpfournisseur.combo_box());
    ui->comboBox_m2->setModel(tmpclient.combo_box());
    ui->comboBox_f2->setModel(tmpfournisseur.combo_box());
}


void MainWindow::on_pb_ajouter_clicked()
{
    int id = ui->ajouter_id->currentText().toInt();
    int prix = ui->ajouter_prix->text().toInt();
    int quantite = ui->ajouter_quantite->text().toInt();
    QDate date_achat = ui->ajouter_date->date();
  Achat a(id,prix,quantite,date_achat);

  bool test=a.ajouter();
  if(test)
{ui->tableView_achat->setModel(tmpachat.afficher());//refresh
      refresh_stats();
      ui->ajouter_id->setModel(tmpachat.afficherid());
      ui->supprimer_id->setModel(tmpachat.afficher1());
      ui->modifier_id->setModel(tmpachat.afficher1());
      ui->chercher_id->setModel(tmpachat.afficher1());

      QMessageBox::information(nullptr, QObject::tr("Ajouter un achat"),
                  QObject::tr("Achat ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un Achat"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_pb_supprimer_clicked()
{
int id = ui->supprimer_id->currentText().toInt();
bool test=tmpachat.supprimer(id);
if(test)
{ui->tableView_achat->setModel(tmpachat.afficher());//refresh
    refresh_stats();
    ui->ajouter_id->setModel(tmpachat.afficherid());
    ui->supprimer_id->setModel(tmpachat.afficher1());
    ui->modifier_id->setModel(tmpachat.afficher1());
    ui->chercher_id->setModel(tmpachat.afficher1());

    QMessageBox::information(nullptr, QObject::tr("Supprimer un achat"),
                QObject::tr("Achat supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un achat"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_pb_modifier_clicked()
{
    int id= ui->modifier_id->currentText().toInt();
    int prix= ui->modifier_prix->text().toInt();
    int quantite= ui->modifier_quantite->text().toInt();
    QDate date_achat= ui->modifier_date->date();

  Achat a(id,prix,quantite,date_achat);
  bool test=a.modifier(id);
  if (test)
  {   ui->tableView_achat->setModel(tmpachat.afficher());//refresh
      refresh_stats();
      ui->ajouter_id->setModel(tmpachat.afficherid());
      ui->supprimer_id->setModel(tmpachat.afficher1());
      ui->modifier_id->setModel(tmpachat.afficher1());
      ui->chercher_id->setModel(tmpachat.afficher1());

          QMessageBox::information(nullptr, QObject::tr("Modifier un achat"),
                      QObject::tr("Achat modifié.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);

      }
      else
          QMessageBox::critical(nullptr, QObject::tr("Modifier un achat"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_chercher_id_activated(const QString &)
{
    QString id=ui->chercher_id->currentText();
        ui->tableView_achat->setModel(tmpachat.chercher(id));
}

void MainWindow::on_pb_trier_clicked()
{
    QString tri=ui->tri->currentText();
    if (tri=="ID")
    {
        ui->tableView_achat->setModel(tmpachat.trier_id());
    }
    else
        ui->tableView_achat->setModel(tmpachat.trier_quantite());
}

void MainWindow::on_imprimer_clicked()
{
    QString num1 = ui->imprimer_achat->text();
        int num = ui->imprimer_achat->text().toInt();

        QSqlQuery query1;

        QString FICHE_ACHAT;
        QString ID_FOURNISSEUR="";
        QString PRIX="";
        QString QUANTITE="";
        QDate DATE_ACHAT;
        QString DATE_ACHAT1="";

        if(num1!=""){
        query1.prepare("select * from ACHAT where ID_FOURNISSEUR=:id");
       query1.bindValue(":id", num);

        if (query1.exec())
        {

            while (query1.next()) {

                 ID_FOURNISSEUR= query1.value(0).toString();
                 PRIX= query1.value(1).toString();
                 QUANTITE= query1.value(2).toString();

                 DATE_ACHAT = query1.value(3).toDate();
                 DATE_ACHAT1=DATE_ACHAT.toString("dd-MM-yyyy");

             }
        }
              QPrinter printer(QPrinter::HighResolution);
                  printer.setPageSize(QPrinter::A4);

                 QPrintDialog *dialog = new QPrintDialog(&printer);
                  if (dialog->exec() == QDialog::Accepted)
                  {               QPainter painter(&printer);
                                  painter.begin(&printer);
                                  int iYPos = 0;
                                  int iWidth = printer.width();
                                  int iHeight = printer.height();
                                  QPixmap pxPic;
                                  pxPic.load("C:/Users/dhiab/Desktop/Farm/images/logo.png", "PNG");
                                  QSize s(iWidth/3, iHeight/5);
                                  QPixmap pxScaledPic = pxPic.scaled(s, Qt::KeepAspectRatio, Qt::FastTransformation);
                                  painter.drawPixmap(3500, iYPos, pxScaledPic.width(), pxScaledPic.height(), pxScaledPic);
                                  iYPos += pxScaledPic.height() + 250;
                                  QFont f;
                                      f.setPointSize(20);
                                      f.setBold(true);
                                      painter.setFont(f);
                                   painter.drawText(1500, 500, "FICHE ACHAT");
                                    painter.drawText(2500, 500, FICHE_ACHAT);
                                   f.setPointSize(15);
                                   f.setBold(true);
                                   painter.setFont(f);
                                   painter.drawText(100, 1000, "ID N°:");
                                   painter.drawText(1500, 1000,ID_FOURNISSEUR);
                                   painter.drawText(100, 1300, "PRIX:");
                                   painter.drawText(1500, 1300,PRIX);
                                   painter.drawText(100, 1600, "QUANTITE:");
                                   painter.drawText(1500, 1600,QUANTITE);
                                   painter.drawText(100, 1900, "DATE ACHAT:");
                                   painter.drawText(1500, 1900,DATE_ACHAT1);



                                  painter.end();

                  }
        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Imprimer une vente"),
                        QObject::tr("Erreur !.\n"
                                    "Veuillez selectionner une vente à imprimer .\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::refresh_stats()
{
    if ( ui->stat_2->layout() != nullptr )
    {
    QLayoutItem* item;
    while ( ( item = ui->stat_2->layout()->takeAt( 0 ) ) != nullptr )
    {
    delete item->widget();
    delete item;
    }
    delete ui->stat_2->layout();
    }
    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(s1.Preparechart());
    ui->stat_2->setLayout(mainLayout);
}

void MainWindow::on_ajouter_vente_clicked()
{
    int matricule = ui->ajouter_matricule->currentText().toInt();
    int quantite = ui->ajouter_quantiteV->text().toInt();
    int prix = ui->ajouter_prixV->text().toInt();
    QDate date_vente = ui->ajouter_dateV->date();
  VENTE v(matricule,quantite,prix,date_vente);

  bool test=v.ajouterV();
  if(test)
{ui->tableView_vente->setModel(tmpvente.afficherV());//refresh
      ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
      ui->supprimer_matricule->setModel(tmpvente.afficher2());
      ui->modifier_matricule->setModel(tmpvente.afficher2());
      ui->chercher_matricule->setModel(tmpvente.afficher2());
      QMessageBox::information(nullptr, QObject::tr("Ajouter un vente"),
                  QObject::tr("Vente ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un Vente"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_supprimer_vente_clicked()
{
int matricule = ui->supprimer_matricule->currentText().toInt();
bool test=tmpvente.supprimerV(matricule);
if(test)
{ui->tableView_vente->setModel(tmpvente.afficherV());//refresh
    ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
    ui->supprimer_matricule->setModel(tmpvente.afficher2());
    ui->modifier_matricule->setModel(tmpvente.afficher2());
    ui->chercher_matricule->setModel(tmpvente.afficher2());
    QMessageBox::information(nullptr, QObject::tr("Supprimer un vente"),
                QObject::tr("Vente supprimée.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un vente"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_modifier_vente_clicked()
{
    int matricule= ui->modifier_matricule->currentText().toInt();
    int quantite= ui->modifier_quantiteV->text().toInt();
    int prix= ui->modifier_prixV->text().toInt();
    QDate date_vente= ui->modifier_dateV->date();

  VENTE v(matricule,quantite,prix,date_vente);
  bool test=v.modifierV(matricule);
  if (test)
  {
      ui->tableView_vente->setModel(tmpvente.afficherV());//refresh
      ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
      ui->supprimer_matricule->setModel(tmpvente.afficher2());
      ui->modifier_matricule->setModel(tmpvente.afficher2());
      ui->chercher_matricule->setModel(tmpvente.afficher2());
          QMessageBox::information(nullptr, QObject::tr("Modifier un vente"),
                      QObject::tr("Vente modifié.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);

      }
      else
          QMessageBox::critical(nullptr, QObject::tr("Modifier un vente"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_chercher_matricule_activated(const QString &)
{
    QString matricule=ui->chercher_matricule->currentText();
        ui->tableView_vente->setModel(tmpvente.chercherV(matricule));
}

void MainWindow::on_Trier_clicked()
{
    QString tri=ui->triV->currentText();
    if (tri=="MATRICULE")
    {
        ui->tableView_vente->setModel(tmpvente.trierV_id());
    }
    else
        ui->tableView_vente->setModel(tmpvente.trierV_quantite());

}

void MainWindow::on_imprimerV_clicked()
{
    QString num1 = ui->imprimer_vente->text();
        int num = ui->imprimer_vente->text().toInt();

        QSqlQuery query1;

        QString FICHE_VENTE;
        QString MATRICULE_CLT="";
        QString QUANTITE="";
        QString PRIX="";
        QDate DATE_VENTE;
        QString DATE_VENTE1="";

        if(num1!=""){
        query1.prepare("select * from VENTE where MATRICULE_CLT=:matricule");
       query1.bindValue(":matricule", num);

        if (query1.exec())
        {

            while (query1.next()) {

                 MATRICULE_CLT= query1.value(0).toString();
                 QUANTITE= query1.value(1).toString();
                 PRIX= query1.value(2).toString();

                 DATE_VENTE = query1.value(3).toDate();
                 DATE_VENTE1=DATE_VENTE.toString("dd-MM-yyyy");

             }
        }
              QPrinter printer(QPrinter::HighResolution);
                  printer.setPageSize(QPrinter::A4);

                 QPrintDialog *dialog = new QPrintDialog(&printer);
                  if (dialog->exec() == QDialog::Accepted)
                  {               QPainter painter(&printer);
                                  painter.begin(&printer);
                                  int iYPos = 0;
                                  int iWidth = printer.width();
                                  int iHeight = printer.height();
                                  QPixmap pxPic;
                                  pxPic.load("C:/Users/DELL/Documents/2ème/2ème semestre/c++/projet/Projet_complet/logo.png", "PNG");
                                  QSize s(iWidth/3, iHeight/5);
                                  QPixmap pxScaledPic = pxPic.scaled(s, Qt::KeepAspectRatio, Qt::FastTransformation);
                                  painter.drawPixmap(3500, iYPos, pxScaledPic.width(), pxScaledPic.height(), pxScaledPic);
                                  iYPos += pxScaledPic.height() + 250;
                                  QFont f;
                                      f.setPointSize(20);
                                      f.setBold(true);
                                      painter.setFont(f);
                                   painter.drawText(1500, 500, "FICHE VENTE");
                                    painter.drawText(2500, 500, FICHE_VENTE);
                                   f.setPointSize(15);
                                   f.setBold(true);
                                   painter.setFont(f);
                                   painter.drawText(100, 1000, "MATRICULE N°:");
                                   painter.drawText(1500, 1000,MATRICULE_CLT);
                                   painter.drawText(100, 1300, "QUANTITE:");
                                   painter.drawText(1500, 1300,QUANTITE);
                                   painter.drawText(100, 1600, "PRIX:");
                                   painter.drawText(1500, 1600,PRIX);
                                   painter.drawText(100, 1900, "DATE VENTE:");
                                   painter.drawText(1500, 1900,DATE_VENTE1);



                                  painter.end();

                  }
        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Imprimer une vente"),
                        QObject::tr("Erreur !.\n"
                                    "Veuillez selectionner une vente à imprimer .\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_modifier_id_activated(const QString &)
{
    QString var=ui->modifier_id->currentText();
      QSqlQuery query1;
      query1.prepare("select * from ACHAT where ID_FOURNISSEUR=:id");
      query1.bindValue(":id", var);

      if (query1.exec())
      {

          while (query1.next()) {

               ui->supprimer_id->setModel(tmpachat.afficher1());
               ui->ajouter_id->setModel(tmpachat.afficher1());

               ui->modifier_id->setCurrentText(query1.value(0).toString());
               ui->modifier_prix->setText(query1.value(1).toString());
               ui->modifier_quantite->setText(query1.value(2).toString());
               ui->modifier_date->setDate(query1.value(3).toDate());

          }
      }
  }

void MainWindow::on_modifier_matricule_activated(const QString &)
{
    QString var=ui->modifier_matricule->currentText();
      QSqlQuery query1;
      query1.prepare("select * from VENTE where MATRICULE_CLT=:matricule");
      query1.bindValue(":matricule", var);

      if (query1.exec())
      {

          while (query1.next()) {

               ui->supprimer_matricule->setModel(tmpvente.afficher2());
               ui->ajouter_matricule->setModel(tmpvente.afficher2());

               ui->modifier_matricule->setCurrentText(query1.value(0).toString());
               ui->modifier_quantiteV->setText(query1.value(1).toString());
               ui->modifier_prixV->setText(query1.value(2).toString());
               ui->modifier_dateV->setDate(query1.value(3).toDate());

          }
      }
}

void MainWindow::on_pb_ajouterCL_clicked()
{

    QString nom= ui->lineEdit_nom->text();
    QString prenom= ui->lineEdit_prenom->text();
    int CIN = ui->lineEdit_cin->text().toInt();



  Client c(CIN,nom,prenom);
  if(CIN < 999999 && CIN > 0 ){
  bool test=c.ajouter();
  if(test)
{
      ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
      ui->comboCINsupp->setModel(tmpclient.combo_box());
      ui->comboCINmodif->setModel(tmpclient.combo_box());
      ui->tabclient->setModel(tmpclient.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un client"),
                  QObject::tr("Client ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un client"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
 }
  else {
          QMessageBox::critical(nullptr, QObject::tr("Erreur !"),
                      QObject::tr("6 premier chiffres = CIN!.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
      }
}

void MainWindow::on_pb_supprimerCL_clicked()
{
    int CIN = ui->comboCINsupp->currentText().toInt();
    bool test=tmpclient.supprimer(CIN);
    if(test)
    {
        ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
        ui->comboCINsupp->setModel(tmpclient.combo_box());
        ui->comboCINmodif->setModel(tmpclient.combo_box());
        ui->tabclient->setModel(tmpclient.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un client"),
                    QObject::tr("Client supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un client"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_pb_modifierCL_clicked()
{
    int CIN = ui->comboCINmodif->currentText().toInt();
    QString nom= ui->lineEdit_nom_2->text();
    QString prenom= ui->lineEdit_prenom_2->text();
  Client c(CIN,nom,prenom);
  bool test=c.modifier();
  if(test)
{     ui->ajouter_matricule->setModel(tmpvente.affichermatricule());
      ui->comboCINsupp->setModel(tmpclient.combo_box());
      ui->comboCINmodif->setModel(tmpclient.combo_box());
      ui->tabclient->setModel(tmpclient.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Modifier un client"),
                  QObject::tr("Client modifié.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Modifier un client"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pb_ajouterF_clicked()
{

    int idF = ui->lineEdit_idf->text().toInt();
    QString nom= ui->lineEdit_nomf->text();
    QDate date_ajout= ui->ajouterdatefournisseur->date();
  fournisseur f(idF,nom, date_ajout);
  bool test=f.ajouter();
  if(test)
{
      ui->ajouter_id->setModel(tmpachat.afficherid());

      ui->comboFsupp->setModel(tmpfournisseur.combo_box());
      ui->comboFmodif->setModel(tmpfournisseur.combo_box());
      ui->tabfournisseur->setModel(tmpfournisseur.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un fournisseur"),
                  QObject::tr("Fournisseur Ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Modifier un fournisseur"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pb_supprimerF_clicked()
{
    int idF = ui->comboFsupp->currentText().toInt();
    bool test=tmpfournisseur.supprimer(idF);
    if(test)
    {ui->tabfournisseur->setModel(tmpfournisseur.afficher());//refresh
        ui->comboFsupp->setModel(tmpfournisseur.combo_box());
        ui->comboFmodif->setModel(tmpfournisseur.combo_box());
        ui->ajouter_id->setModel(tmpachat.afficherid());

        QMessageBox::information(nullptr, QObject::tr("Supprimer un fournisseur"),
                    QObject::tr("fournisseur supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un fournisseur"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pb_modifierF_clicked()
{
    int idF = ui->comboFmodif->currentText().toInt();
    QString nom= ui->lineEdit_nomf_2->text();
    QDate date_ajout= ui->modifierdatefournisseur->date();
    fournisseur f(idF,nom, date_ajout);
  bool test=f.modifier();
  if(test)
{ui->tabfournisseur->setModel(tmpfournisseur.afficher());//refresh
      ui->comboFsupp->setModel(tmpfournisseur.combo_box());
      ui->comboFmodif->setModel(tmpfournisseur.combo_box());
      ui->ajouter_id->setModel(tmpachat.afficherid());

QMessageBox::information(nullptr, QObject::tr("Modifier un fournisseur"),
                  QObject::tr("fournisseur modifié.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Modifier un fournisseur"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_ch_nom_clicked()
{
    QString nom = ui->nomch->text();
    ui->tabclient->setModel(tmpclient.recherche_nom(nom));
}

void MainWindow::on_nomch_windowIconTextChanged(const QString &arg)
{
    ui->tabclient->setModel(tmpclient.recherche_nom(arg));
}

void MainWindow::on_ch_cin_clicked()
{
    int CIN = ui->cinch->text().toInt();
    ui->tabclient->setModel(tmpclient.recherche_CIN(CIN));
}

void MainWindow::on_cinch_windowIconTextChanged(const QString &arg)
{
    int CIN = arg.toInt();
     ui->tabclient->setModel(tmpclient.recherche_CIN(CIN));
}

void MainWindow::on_ch_cin_3_clicked()
{
    int idF = ui->cinch_3->text().toInt();
    ui->tabfournisseur->setModel(tmpfournisseur.recherche_idF(idF));
}

void MainWindow::on_cinch_3_windowIconTextChanged(const QString &arg)
{
    int idF = arg.toInt();
        ui->tabfournisseur->setModel(tmpfournisseur.recherche_idF(idF));
}

void MainWindow::on_ch_nom_3_clicked()
{
    QString nom = ui->nomch_3->text();
    ui->tabfournisseur->setModel(tmpfournisseur.recherche_nom(nom));
}

void MainWindow::on_nomch_3_windowIconTextChanged(const QString &arg)
{
    ui->tabfournisseur->setModel(tmpfournisseur.recherche_nom(arg));
}

void MainWindow::on_trier_cin_clicked()
{
    ui->tabclient->setModel(tmpclient.trier_CIN());
}

void MainWindow::on_trier_id_clicked()
{
    ui->tabfournisseur->setModel(tmpfournisseur.trier_idF());
}

void MainWindow::on_pb_ajouterP_clicked()
{
    int ref_produit = ui->lineEdit_ref->text().toInt();
    QString type = ui->combocombo->currentText();
    int prix_unitaire = ui->lineEdit_prix->text().toInt();
    int matricule = ui->comboBox_m->currentText().toInt();
    int id = ui->comboBox_f->currentText().toInt();

  produit p(ref_produit,type,prix_unitaire,matricule,id);

  bool test=p.ajouter();

  if(test)

{      refresh_stat();

      ui->comboPsupp->setModel(tmpproduit.combo_box());
      ui->comboPmodif->setModel(tmpproduit.combo_box());
      ui->tabproduit->setModel(tmpproduit.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un produit"),
                  QObject::tr("produit Ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un produit"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pb_supprimerP_clicked()
{
    int ref = ui->comboPsupp->currentText().toInt();
    bool test=tmpproduit.supprimer(ref);
    if(test)
    {refresh_stat();
        ui->tabproduit->setModel(tmpproduit.afficher());//refresh
        ui->comboPsupp->setModel(tmpproduit.combo_box());
        ui->comboPmodif->setModel(tmpproduit.combo_box());
        QMessageBox::information(nullptr, QObject::tr("Supprimer un produit"),
                    QObject::tr("produit supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un produit"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pb_modifierP_clicked()
{
    int ref_produit = ui->comboPmodif->currentText().toInt();
    QString type = ui->combocombo_2->currentText();
    int prix_unitaire = ui->lineEdit_prix_2->text().toInt();
    int matricule = ui->comboBox_m2->currentText().toInt();
    int id = ui->comboBox_f2->currentText().toInt();

    produit p(ref_produit,type,prix_unitaire,matricule,id);
      bool test=p.modifier();
      if(test)
    {      refresh_stat();
          ui->tabproduit->setModel(tmpproduit.afficher());//refresh
          ui->comboPsupp->setModel(tmpproduit.combo_box());
          ui->comboPmodif->setModel(tmpproduit.combo_box());
    QMessageBox::information(nullptr, QObject::tr("Modifier un produit"),
                      QObject::tr("produit modifié.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);

    }
      else
          QMessageBox::critical(nullptr, QObject::tr("Modifier un produit"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_rech_ref_clicked()
{
    int ref = ui->ref_rech->text().toInt();
    ui->tabproduit->setModel(tmpproduit.recherche_ref_produit(ref));
}

void MainWindow::on_ref_rech_windowIconTextChanged(const QString &arg1)
{
    int ref = arg1.toInt();
        ui->tabproduit->setModel(tmpproduit.recherche_ref_produit(ref));
}

void MainWindow::on_trie_ref_clicked()
{
    ui->tabproduit->setModel(tmpproduit.trier_ref_produit());
}

void MainWindow::on_tabWidget_7_currentChanged(int index)
{
    if(index==2)
    {
        delete mainLayout;
        mainLayout=new QVBoxLayout ;
        mainLayout->addWidget(Sf.Preparechart());

        ui->widget_stat->setLayout(mainLayout);
    }
}

void MainWindow::on_combo_trie_rech_currentTextChanged(const QString &arg1)
{
            if(arg1=="")
                ui->tabclient->setModel(tmpclient.afficher());
            if(arg1 == "Trie par CIN")
                ui->tabclient->setModel(tmpclient.trier_CIN());
            else if (arg1 == "Rechercher par CIN")
                ui->tabclient->setModel(tmpclient.recherche_CIN(ui->combo_line->text().toInt()));


}

void MainWindow::on_combo_line_textChanged(const QString &arg1)
{
        ui->tabclient->setModel(tmpclient.recherche_CIN(arg1.toInt()));

}


void MainWindow::on_comboCINmodif_activated(const QString &)
{

        QString var=ui->comboCINmodif->currentText();
          QSqlQuery query1;
          query1.prepare("select * from CLIENT where CIN=:CIN");
          query1.bindValue(":CIN", var);

          if (query1.exec())
          {

              while (query1.next()) {



                   ui->comboCINmodif->setCurrentText(query1.value(0).toString());
                   ui->lineEdit_nom_2->setText(query1.value(1).toString());
                   ui->lineEdit_prenom_2->setText(query1.value(2).toString());

              }
          }
}

void MainWindow::on_comboFmodif_activated(const QString &)
{
    QString var=ui->comboFmodif->currentText();
      QSqlQuery query1;
      query1.prepare("select * from FOURNISSEUR where idF=:idF");
      query1.bindValue(":idF", var);

      if (query1.exec())
      {

          while (query1.next()) {



               ui->comboFmodif->setCurrentText(query1.value(0).toString());
               ui->lineEdit_nomf_2->setText(query1.value(1).toString());
               ui->modifierdatefournisseur->setDate(query1.value(2).toDate());

          }
      }
}

void MainWindow::refresh_stat()
{
    if ( ui->widget_stat->layout() != nullptr )
    {
    QLayoutItem* item;
    while ( ( item = ui->widget_stat->layout()->takeAt( 0 ) ) != nullptr )
    {
    delete item->widget();
    delete item;
    }
    delete ui->widget_stat->layout();
    }
    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(Sf.Preparechart());
    ui->widget_stat->setLayout(mainLayout);
}

//Hiz
void MainWindow::on_rechercheButton_clicked() //on_crud_materiel_tabBarClicked()
{
    QString type= ui->typeEdit->text() ;
    ui->tab_filtre->setModel(tmpmateriel.afficher(type));

}



//Ajouter

void MainWindow::on_pb_ajouter_1_clicked()
{

    QString msg("");
    bool idtest;
    bool idtest_1;
    bool idtest_2;
    bool idtest_3;
    bool valid=true;
    int id = ui->lineEdit_id_1->text().toInt(&idtest);
    int AgentId = ui->lineEdit_agId->currentText().toInt(&idtest_1);
    int MaterielId = ui->lineEdit_matId->currentText().toInt(&idtest_2);

    int cout = ui->lineEdit_cou->text().toInt(&idtest_3);
    int IDalready =0 ;
    QDate date= ui->dateEdit_3->date();

    if (!ui->lineEdit_id_1->text().isEmpty() && idtest){
       QSqlQuery * qry1 = new QSqlQuery ();
       qry1 -> prepare ("select ID from maintien where ID =:id");
       qry1->bindValue(":id", id);
       qry1-> exec();
       IDalready   = qry1->boundValue(0).toInt();
       if (qry1->next())
       {
           msg+=QString("*Identifiant existe déjà\n");
           valid=false;
       }
    }
    if (ui->lineEdit_id_1->text().isEmpty())
    {
        msg+=QString("*Identifiant requis\n");
        valid=false;
    }

    if (!ui->lineEdit_id_1->text().isEmpty() && !idtest)
    {
        msg+=QString("*Identifiant doit etre un entier\n");
         valid=false;
    }
    if (ui->lineEdit_agId->currentText().isEmpty())
    {
        msg+=QString("*Identifiant agent requis\n");
        valid=false;
    }

    if (!ui->lineEdit_agId->currentText().isEmpty() && !idtest_1)
    {
        msg+=QString("*Identifiant agent doit etre un entier\n");
         valid=false;
    }
    if (ui->lineEdit_matId->currentText().isEmpty())
    {
        msg+=QString("*Identifiant matériel requis\n");
        valid=false;
    }

    if (!ui->lineEdit_matId->currentText().isEmpty() && !idtest_2)
    {
        msg+=QString("*Identifiant matériel doit etre un entier\n");
         valid=false;
    }
    if (ui->lineEdit_cou->text().isEmpty())
    {
       msg+=QString("*cout requis\n");
       valid=false;
    }
    if (!ui->lineEdit_cou->text().isEmpty() && !idtest_3)
    {
        msg+=QString("*Le cout doit etre un entier\n");
         valid=false;
    }


    if (valid) {

        Maintien ma (MaterielId, AgentId,id, date, cout);
        bool test=ma.ajouter();

        if(test)
      {

      QMessageBox::information(nullptr, QObject::tr("Ajouter un maintien"),
                        QObject::tr("maintien ajouté ajouté.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
      QString okd="";
      notification ok;
      ok.notification_maintien(okd);

      }
        else
            QMessageBox::critical(nullptr, QObject::tr("Ajouter un maintien"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un maintien"),
                    msg, QMessageBox::Cancel);

    }



}

void MainWindow::on_pb_ajouter_3_clicked()
{
    bool idtest, qtetest;
    QString msg("");
    bool valid=true;
    int IDalready = 0 ;
    int id = ui->lineEdit_id_4->text().toInt(&idtest);
    QString type= ui->lineEdit_quantite_3->text() ;


    int quantite= ui->lineEdit_quantite_4->text().toInt(&qtetest);


    if (!ui->lineEdit_id_4->text().isEmpty() && idtest){
       QSqlQuery * qry1 = new QSqlQuery ();
       qry1 -> prepare ("select ID from Matériel where ID =:id");
       qry1->bindValue(":id", id);
       qry1-> exec();
       IDalready   = qry1->boundValue(0).toInt();
       if (qry1->next())
       {
           msg+=QString("*Identifiant existe déjà\n");
           valid=false;
       }
    }
    //controle de saisie
  if (ui->lineEdit_id_4->text().isEmpty())
  {
      msg+=QString("*Identifiant requis\n");
      valid=false;
  }
  if ( ui->lineEdit_quantite_4->text().isEmpty())
  {
      msg+=QString("*Quantite requise\n");
      valid=false;
  }
  if (!ui->lineEdit_id_4->text().isEmpty() && !idtest)
  {
      msg+=QString("*Identifiant doit etre un entier\n");
       valid=false;
  }
  if ( !ui->lineEdit_quantite_4->text().isEmpty() && !qtetest)
  {
      msg+=QString("*Quantite doit etre un entier\n");
      valid=false;
  }

if (valid)
{
    Materiel e(id,type,quantite);
    bool test=e.ajouter();
    if(test)
  {
  QMessageBox::information(nullptr, QObject::tr("Ajouter un matériel"),
                    QObject::tr("Matériel ajouté.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
  QString okd="";
  notification ok;
  ok.notification_materiel(okd);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un matériel"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}
else {

    QMessageBox::critical(nullptr, QObject::tr("Ajouter un matériel"),
                msg, QMessageBox::Cancel);
}


}



//Modifier

void MainWindow::on_pb_modifier_M_clicked()
{

    QString msg("");
    bool idtest;
    bool idtest_1;
    bool idtest_2;
    bool idtest_3;
    bool valid=true;
    int id = ui->lineEdit_id_10->currentText().toInt(&idtest);
    int AgentId = ui->lineEdit_agId_2->currentText().toInt(&idtest_1);
    int MaterielId = ui->lineEdit_matId_2->currentText().toInt(&idtest_2);

    int cout = ui->lineEdit_cou_2->text().toInt(&idtest_3);
   QDate date= ui->dateEdit_2_M->date();


    if (ui->lineEdit_id_10->currentText().isEmpty())
    {
        msg+=QString("*Identifiant requis\n");
        valid=false;
    }

    if (!ui->lineEdit_id_10->currentText().isEmpty() && !idtest)
    {
        msg+=QString("*Identifiant doit etre un entier\n");
         valid=false;
    }
    if (ui->lineEdit_agId_2->currentText().isEmpty())
    {
        msg+=QString("*Identifiant agent requis\n");
        valid=false;
    }

    if (!ui->lineEdit_agId_2->currentText().isEmpty() && !idtest_1)
    {
        msg+=QString("*Identifiant agent doit etre un entier\n");
         valid=false;
    }
    if (ui->lineEdit_matId_2->currentText().isEmpty())
    {
        msg+=QString("*Identifiant matériel requis\n");
        valid=false;
    }

    if (!ui->lineEdit_matId_2->currentText().isEmpty() && !idtest_2)
    {
        msg+=QString("*Identifiant matériel doit etre un entier\n");
         valid=false;
    }
    if (ui->lineEdit_cou_2->text().isEmpty())
    {
       msg+=QString("*cout requis\n");
       valid=false;
    }
    if (!ui->lineEdit_cou_2->text().isEmpty() && !idtest_3)
    {
        msg+=QString("*Le cout doit etre un entier\n");
         valid=false;
    }


    if (valid) {

        Maintien ma (MaterielId, AgentId,id, date, cout);
        bool test=ma.modifier();

        if(test)
      {

      QMessageBox::information(nullptr, QObject::tr("Modifier un maintien"),
                        QObject::tr("maintien modifié .\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

      }
        else
            QMessageBox::critical(nullptr, QObject::tr("Modifier un maintien"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("Modifier un maintien"),
                    msg, QMessageBox::Cancel);

    }



}


void MainWindow::on_pb_modifier_2_clicked()
{
    bool idtest, qtetest;
    QString msg("");
    bool valid=true;

    int id = ui->lineEdit_id->currentText().toInt(&idtest);
    QString type= ui->lineEdit_quantite_2->text();


    int quantite= ui->lineEdit_quantite->text().toInt(&qtetest);



    //controle de saisie
  if (ui->lineEdit_id->currentText().isEmpty())
  {
      msg+=QString("*Identifiant requis\n");
      valid=false;
  }
  if ( ui->lineEdit_quantite->text().isEmpty())
  {
      msg+=QString("*Quantite requise\n");
      valid=false;
  }
  if (ui->lineEdit_quantite_2->text().isEmpty())
  {
      msg+=QString("*Type requis\n");
      valid=false;
  }
  if (!ui->lineEdit_id->currentText().isEmpty() && !idtest)
  {
      msg+=QString("*Identifiant doit etre un entier\n");
       valid=false;
  }
  if ( !ui->lineEdit_quantite->text().isEmpty() && !qtetest)
  {
      msg+=QString("*Quantite doit etre un entier\n");
      valid=false;
  }


if (valid)
{
    Materiel e(id,type,quantite);
    bool test=e.modifier();
    if(test)
  {
  QMessageBox::information(nullptr, QObject::tr("Modifier un matériel"),
                    QObject::tr("Matériel modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Modifier un matériel"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}
else {

    QMessageBox::critical(nullptr, QObject::tr("Modifier un matériel"),
                msg, QMessageBox::Cancel);
}


}

void MainWindow::on_tabModifierMaintien_tabBarClicked()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery * qry = new QSqlQuery ();
    qry -> prepare ("select ID from maintien");
    qry-> exec();
    model->setQuery(*qry);
    ui->lineEdit_id_10->setModel(model);
    ui->lineEdit_id_2->setModel(model);
    QSqlQueryModel * model1 = new QSqlQueryModel();
    QSqlQuery * qry1 = new QSqlQuery ();
    qry1 -> prepare ("select ID from matériel");
    qry1-> exec();
    model1->setQuery(*qry1);
    ui->lineEdit_id->setModel(model1);
    ui->lineEdit_id_5->setModel(model);
}



//Statistiques



void MainWindow::on_Statistiques_maintenance_customContextMenuRequested() {}
void MainWindow::on_crud_maintenance_tabBarClicked()

  {
    connexion c;
    QStandardItemModel *modelBox= new QStandardItemModel();
    QStringList horzHeaders;
    horzHeaders << "TYPE" << "OCCUR" << "SOMME";
        QPieSeries *series = new QPieSeries();

     for(int i = 0; i < tmpstatistique2.afficherstats()->rowCount(); ++i)
     {
         QList<QStandardItem *> list;


         list.append(new QStandardItem(tmpstatistique2.afficherstats()->record(i).value("TYPE").toString()));
         list.append(new QStandardItem(tmpstatistique2.afficherstats()->record(i).value("OCCUR").toString()));
         list.append(new QStandardItem(tmpstatistique2.afficherstats()->record(i).value("SOMME").toString()));




        series->append(tmpstatistique2.afficherstats()->record(i).value("TYPE").toString(),tmpstatistique2.afficherstats()->record(i).value("OCCUR").toInt()) ;
        modelBox->appendRow(list);

     }

     modelBox->setHorizontalHeaderLabels(horzHeaders);

     QPieSlice *slice = series->slices().at(1);
       slice->setExploded(true);
       slice->setLabelVisible(true);
       slice->setPen(QPen(Qt::darkGreen, 2));
       slice->setBrush(Qt::green);

     QChart *chart = new QChart();
     chart->addSeries(series);
     chart->setTitle("TYPES ET MAINTENANCE");
     chart->setAnimationOptions(QChart::AllAnimations);





     series->setPieSize(0.7);
     series->setHorizontalPosition(0.4);
     series->setVerticalPosition(0.4);

     QChartView *chartview = new QChartView(chart);
     chartview->setParent(ui->frame_stat);
     //c.fermerConnexion();
     //c.ouvrirConnexion();

}



//Supprimer


void MainWindow::on_pb_Supprimer_1_clicked()
{
    QString msg("");
    bool idtest;
    bool valid=true;
    int id = ui->lineEdit_id_2->currentText().toInt(&idtest);

    if (ui->lineEdit_id_2->currentText().isEmpty())
    {
        msg+=QString("*Identifiant requis\n");
        valid=false;
    }

    if (!ui->lineEdit_id_2->currentText().isEmpty() && !idtest)
    {
        msg+=QString("*Identifiant doit etre un entier\n");
         valid=false;
    }

    if (valid){
        bool test=tmpmaintien.supprimer(id);
        if(test)
        {


            QMessageBox::information(nullptr, QObject::tr("Supprimer un maintien"),
                        QObject::tr("maintien supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un maintien"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else {

        QMessageBox::critical(nullptr, QObject::tr("Supprimer un maintien"),
                    msg, QMessageBox::Cancel);
    }

}

void MainWindow::on_pb_Supprimer_2_clicked()
{
    QString msg("");
    bool idtest;
    bool valid=true;
    int id = ui->lineEdit_id_5->currentText().toInt(&idtest);




    if (ui->lineEdit_id_5->currentText().isEmpty())
    {
        msg+=QString("*Identifiant requis\n");
        valid=false;
    }

    if (!ui->lineEdit_id_5->currentText().isEmpty() && !idtest)
    {
        msg+=QString("*Identifiant doit etre un entier\n");
         valid=false;
    }

    if (valid){

        bool test=tmpmateriel.supprimer(id);
        if(test)
        {
            QMessageBox::information(nullptr, QObject::tr("Supprimer un materiel"),
                        QObject::tr("Matériel supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un matériel"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

    }

    else {

        QMessageBox::critical(nullptr, QObject::tr("Supprimer un matériel"),
                    msg, QMessageBox::Cancel);
    }




}
void MainWindow::on_tabSuppMaintien_tabBarClicked()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery * qry = new QSqlQuery ();
    qry -> prepare ("select ID from maintien");
    qry-> exec();
    model->setQuery(*qry);
    ui->lineEdit_id_2->setModel(model);
    QSqlQueryModel * model1 = new QSqlQueryModel();
    QSqlQuery * qry1 = new QSqlQuery ();
    qry1 -> prepare ("select ID from matériel");
    qry1-> exec();
    model1->setQuery(*qry1);
    ui->lineEdit_id_5->setModel(model1);
}


void MainWindow::on_crud_materiel_tabBarClicked()
{
    ui->tab_affM->setModel(tmpmateriel.afficher());
    ui->tab_affMa->setModel(tmpmaintien.afficher());
}

void MainWindow::on_tabWidget_M_currentChanged()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery * qry = new QSqlQuery ();
    qry -> prepare ("select ID from maintien");
    qry-> exec();
    model->setQuery(*qry);
    ui->lineEdit_id_10->setModel(model);
    ui->lineEdit_id_2->setModel(model);

}



void MainWindow::on_crud_materiel_currentChanged()
{
    QSqlQueryModel * model1 = new QSqlQueryModel();
    QSqlQuery * qry1 = new QSqlQuery ();
    qry1 -> prepare ("select ID from matériel");
    qry1-> exec();
    model1->setQuery(*qry1);
    //ui->lineEdit_id->setModel(model1);
    //ui->lineEdit_id_5->setModel(model1);
    ui->lineEdit_id_5->setModel(tmpmateriel.afficher_id());
    ui->lineEdit_id->setModel(tmpmateriel.afficher_id());
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery * qry = new QSqlQuery ();
    qry -> prepare ("select ID from maintien");
    qry-> exec();
    model->setQuery(*qry);
    ui->lineEdit_id_10->setModel(model);

    QSqlQueryModel * model2 = new QSqlQueryModel();
    QSqlQuery * qry2 = new QSqlQuery ();
    qry1 -> prepare ("select ID from agent");
    qry1-> exec();
    model1->setQuery(*qry2);
    ui->lineEdit_agId_2->setModel(model2);
    ui->lineEdit_matId_2->setModel(model1);
    ui->lineEdit_agId->setModel(model2);
    ui->lineEdit_matId->setModel(model1);

}

void MainWindow::on_crud_maintenance_currentChanged()
{

    ui->tab_affMa->setModel(tmpmaintien.afficher());
    QSqlQueryModel * model1 = new QSqlQueryModel();
    QSqlQuery * qry1 = new QSqlQuery ();
    qry1 -> prepare ("select ID from matériel");
    qry1-> exec();
    model1->setQuery(*qry1);
    //ui->lineEdit_id->setModel(model1);
    //ui->lineEdit_id_5->setModel(model1);
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery * qry = new QSqlQuery ();
    qry -> prepare ("select ID from maintien");
    qry-> exec();
    model->setQuery(*qry);
    ui->lineEdit_id_10->setModel(model);

    QSqlQueryModel * model2 = new QSqlQueryModel();
    QSqlQuery * qry2 = new QSqlQuery ();
    qry2 -> prepare ("select ID from agent");
    qry2-> exec();
    model2->setQuery(*qry2);
    ui->lineEdit_agId_2->setModel(model2);
    ui->lineEdit_matId_2->setModel(model1);
    ui->lineEdit_agId->setModel(model2);
    ui->lineEdit_matId->setModel(model1);

}

void MainWindow::on_crud_Ag_M_currentChanged()
{
    QSqlQueryModel * model1 = new QSqlQueryModel();
    QSqlQuery * qry1 = new QSqlQuery ();
    qry1 -> prepare ("select ID from agent");
    qry1-> exec();
    model1->setQuery(*qry1);
    ui->lineEdit_Ag_Id_Mod->setModel(model1);
    ui->lineEdit_Ag_Id_Supp->setModel(model1);

    ui->tab_affM_2->setModel(tmpagent.afficher());
}



void MainWindow::on_pb_Ag_ajouter_clicked()
{
    bool idtest;
    QString msg("");
    bool valid=true;
       int IDalready = 0;

    int id = ui->lineEdit_Ag_Id->text().toInt(&idtest);

    QString Nom= ui->lineEdit_Ag_MainteanceId->text() ;
    QString Entreprise= ui->lineEdit_Ag_Entreprise->text() ;



 if (!ui->lineEdit_Ag_Id->text().isEmpty() && idtest){
    QSqlQuery * qry1 = new QSqlQuery ();
    qry1 -> prepare ("select ID from agent where ID =:id");
    qry1->bindValue(":id", id);
    qry1-> exec();
    IDalready   = qry1->boundValue(0).toInt();
    if (qry1->next())
    {
        msg+=QString("*Identifiant existe déjà\n");
        valid=false;
    }
 }
    //controle de saisie

  if (ui->lineEdit_Ag_Id->text().isEmpty())
  {
      msg+=QString("*Identifiant requis\n");
      valid=false;
  }
  if ( ui->lineEdit_Ag_MainteanceId->text().isEmpty())
  {
      msg+=QString("*Nom requis\n");
      valid=false;
  }
  if ( ui->lineEdit_Ag_Entreprise->text().isEmpty())
  {
      msg+=QString("*Nom de l entreprise est requis\n");
      valid=false;
  }
  if (!ui->lineEdit_Ag_Id->text().isEmpty() && !idtest)
  {
      msg+=QString("*Identifiant doit etre un entier\n");
       valid=false;
  }


if (valid)
{
    Agent a(id,Entreprise,Nom);
    bool test=a.ajouter();
    if(test)
  {
  QMessageBox::information(nullptr, QObject::tr("Ajouter un agent"),
                    QObject::tr("Agent ajouté.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un agent"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}
else {

    QMessageBox::critical(nullptr, QObject::tr("Ajouter un agent"),
                msg, QMessageBox::Cancel);
}


}





void MainWindow::on_pb_Ag_modifier_clicked()
{
    bool idtest;
    QString msg("");
    bool valid=true;

    int id = ui->lineEdit_Ag_Id_Mod->currentText().toInt(&idtest);
    QString Nom= ui->lineEdit_Ag_MainteanceId_Mod->text() ;
    QString Entreprise= ui->lineEdit_Ag_Entreprise_Mod->text() ;





    //controle de saisie
  if (ui->lineEdit_Ag_Id_Mod->currentText().isEmpty())
  {
      msg+=QString("*Identifiant requis\n");
      valid=false;
  }
  if ( ui->lineEdit_Ag_MainteanceId_Mod->text().isEmpty())
  {
      msg+=QString("*Nom requis\n");
      valid=false;
  }
  if ( ui->lineEdit_Ag_Entreprise_Mod->text().isEmpty())
  {
      msg+=QString("*Nom de l entreprise est requis\n");
      valid=false;
  }
  if (!ui->lineEdit_Ag_Id_Mod->currentText().isEmpty() && !idtest)
  {
      msg+=QString("*Identifiant doit etre un entier\n");
       valid=false;
  }


if (valid)
{
    Agent a(id,Entreprise,Nom);
    bool test=a.modifier();
    if(test)
  {
  QMessageBox::information(nullptr, QObject::tr("Modifier un agent"),
                    QObject::tr("Agent modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Modifier un agent"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}
else {

    QMessageBox::critical(nullptr, QObject::tr("Modifier un agent"),
                msg, QMessageBox::Cancel);
}


}


void MainWindow::on_pb_Ag_Supp_clicked()
{
    QString msg("");
    bool idtest;
    bool valid=true;
    int id = ui->lineEdit_Ag_Id_Supp->currentText().toInt(&idtest);




    if (ui->lineEdit_Ag_Id_Supp->currentText().isEmpty())
    {
        msg+=QString("*Identifiant requis\n");
        valid=false;
    }

    if (!ui->lineEdit_Ag_Id_Supp->currentText().isEmpty() && !idtest)
    {
        msg+=QString("*Identifiant doit etre un entier\n");
         valid=false;
    }

    if (valid){

        bool test=tmpagent.supprimer(id);
        if(test)
        {
            QMessageBox::information(nullptr, QObject::tr("Supprimer un agent"),
                        QObject::tr("agent supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un agent"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

    }

    else {

        QMessageBox::critical(nullptr, QObject::tr("Supprimer un agent"),
                    msg, QMessageBox::Cancel);
    }




}







void MainWindow::on_comboBox_5_currentTextChanged(const QString &arg1)
{ QString tri=arg1;
    if (tri=="ID")
    {
        ui->tab_affM->setModel(tmpmateriel.trier_id());
    }
    else
        ui->tab_affM->setModel(tmpmateriel.trier_type());

}

