#include "Agent.h"
#include <QDebug>
#include <QSqlRecord>

using namespace std;
Agent::Agent()
{

}

Agent::Agent( int Id, QString entreprise, QString Nom)
{
    this->Id=Id;
    this->entreprise=entreprise;
    this->Nom=Nom;
}

bool Agent::ajouter(){

    QSqlQuery query;

    QString id= QString::number(Id);

    query.prepare("INSERT INTO agent (ID, ENTREPRISE, Nom) "
                  "VALUES (:id, :entreprise, :Nom)");
    query.bindValue(":entreprise", entreprise);
    query.bindValue(":Nom", Nom);
    query.bindValue(":id", id);


    qDebug() <<"entreprise:  " << entreprise;
    qDebug() <<"Nom:  " << Nom;
    qDebug() <<"id:  " << id;


    return    query.exec();
}

QSqlQueryModel * Agent::afficher()
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select ID,  ENTREPRISE, Nom from agent");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("ENTREPRISE"));

    return model;
}



QSqlQueryModel * Agent::afficher_id()

{
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select ID from Agent");
   //pour afficher les ids sélectionnées à partir de la requête et résultant dans model.

    return model;
}
/*
QSqlQueryModel * Agent::afficher(QString entreprise1, QString entreprise2)
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select ID, AGENT_ID, MATéRIEL_ID, H_DATE, COUT from agent where ENTREPRISE>= " + entreprise1 + " and H_DATE<= " + entreprise2 );
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("AGENT_ID"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("MATERIEL_ID"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("ENTREPRISE"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("PAYMENT"));

    return model;
}
*/
bool Agent::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from agent where ID = :id");
query.bindValue(":id", res);
return    query.exec();
}

bool Agent::modifier(){
    QSqlQuery query;
    QString id_res= QString::number(Id);
    query.prepare("UPDATE Agent SET  entreprise=:entreprise , nom =:nom where ID = :id");
    query.bindValue(":id", id_res);
    query.bindValue(":nom", Nom);
    query.bindValue(":entreprise", entreprise);
    return    query.exec();
}


