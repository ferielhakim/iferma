#ifndef OUVRIERS_H
#define OUVRIERS_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class ouvriers
{
public:
    ouvriers();
    ouvriers(int,QString,QString,int,int,QString,int,int,int,int);
    int get_idOuv();
    QString get_nom();
    QString get_prenom();
    int get_age();
    int get_numTel();
    QString get_fonction();
    int get_salaireM();
    int get_HTS();
    int get_congeA();
    int get_primeA();

    bool ajouter();
    QSqlQueryModel * afficher();
     QSqlQueryModel * afficher2();
     QSqlQueryModel * afficher3();
     QSqlQueryModel * afficher4();
    bool supprimer(int);
   QSqlQueryModel * chercher(const QString &);
   bool modifier(int id);


private:
   int idOuv,age,HTS,congeA,salaireM,primeA,numTel;
    QString nom,prenom,fonction;
    //long numTel ;



};

#endif // OUVRIERS_H
