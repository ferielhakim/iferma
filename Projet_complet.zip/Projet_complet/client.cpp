#include "client.h"
#include<QDebug>

Client::Client()
{
    CIN=0;
    nom="";
    prenom="";

}

Client::Client( int CIN,QString nom,QString prenom)
{
  this->CIN=CIN;
  this->nom=nom;
  this->prenom=prenom;

}

QString Client::get_nom(){return  nom;}
QString Client::get_prenom(){return prenom;}
int Client::get_CIN(){return  CIN;}


bool Client::ajouter(){
    QSqlQuery query;
    QString res= QString::number(CIN);
    query.prepare("INSERT INTO client (CIN, nom, prenom) "
                        "VALUES (:CIN, :nom, :prenom)");
    query.bindValue(":CIN", res);
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);

    return query.exec();
}

QSqlQueryModel * Client::afficher()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("Select * from client");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));


    return model;
}

bool Client::supprimer(int CIN)
{
    QSqlQuery query;
    QString res= QString::number(CIN);
    query.prepare("Delete from client where CIN = :CIN");
    query.bindValue(":CIN", res);
    return query.exec();
}

bool Client::modifier()
{
    QSqlQuery query;
    QString CIN= QString::number(this->CIN);
    QString nom= this->nom;
    QString prenom= this->prenom;
    query.prepare("UPDATE client SET nom =:nom , prenom=:prenom  WHERE CIN =:CIN");
    query.bindValue(":CIN",CIN);
    query.bindValue(":nom",nom);
    query.bindValue(":prenom",prenom);
    return  query.exec();
}

QSqlQueryModel * Client::combo_box(){
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("Select CIN from client");
    return model;
}

QSqlQueryModel * Client::recherche_CIN(int CIN){
    QSqlQueryModel * model = new QSqlQueryModel();
    QString res = QString::number(CIN);
    model->setQuery("Select * From client WHERE CIN = " + res );
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));

    return model;
}


/*QSqlQueryModel* Client:: recherche(int x,int i) {
QSqlQueryModel *model = new QSqlQueryModel() ;
QString header = ("SELECT * FROM client WHERE "+CIN+" LIKE '"+x+"%'");
model->setQuery(header);
model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));
    return model ;
}*/


QSqlQueryModel * Client::recherche_nom(QString nom){
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("Select * From client WHERE nom ='" +nom+"' ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));

    return model;
}

QSqlQueryModel * Client::trier_CIN()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("Select * from client\
                         Order by CIN DESC");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));

    return model;
}



