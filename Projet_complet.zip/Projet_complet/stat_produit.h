#ifndef STAT_PRODUIT_H
#define STAT_PRODUIT_H
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QDebug>
#include <string>
#include <QPainter>
#include <QMessageBox>
#include <QtCharts>
#include <QtCharts/QChartView>

class Stat_produit
{
    QChart *chart;
    QChartView *chartView;
public:
    Stat_produit();  
    QChartView * Preparechart();
};

#endif // STAT_PRODUIT_H
