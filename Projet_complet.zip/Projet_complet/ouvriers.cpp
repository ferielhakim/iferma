#include "ouvriers.h"
#include <QDebug>

ouvriers::ouvriers()
{
idOuv=0;
nom="";
prenom="";
age=0;
numTel=0;
fonction="";
salaireM=0;
HTS=0;
congeA=0;
primeA=0;
}
ouvriers::ouvriers(int idOuv,QString nom,QString prenom,int age,int numTel,QString fonction,int salaireM,int HTS,int congeA,int primeA)
{
    this->idOuv=idOuv;
    this->nom=nom;
    this->prenom=prenom;
    this->age=age;
    this->numTel=numTel;
    this->fonction=fonction;
    this->salaireM=salaireM;
    this->HTS=HTS;
    this->congeA=congeA;
    this->primeA=primeA;
}

int ouvriers::get_idOuv(){return  idOuv;}
QString ouvriers::get_nom(){return  nom;}
QString ouvriers::get_prenom(){return prenom;}
int ouvriers::get_age(){return age;}
int ouvriers::get_numTel(){return numTel;}
QString ouvriers::get_fonction(){return fonction;}
int ouvriers::get_salaireM(){return salaireM;}
int ouvriers::get_HTS(){return HTS;}
int ouvriers::get_congeA(){return congeA;}
int ouvriers::get_primeA(){return primeA;}

bool ouvriers::ajouter()
{
QSqlQuery query;
QString res= QString::number(idOuv);
QString res1= QString::number(age);
QString res2= QString::number(numTel);
QString res3= QString::number(salaireM);
QString res4= QString::number(HTS);
QString res5= QString::number(congeA);
QString res6= QString::number(primeA);

query.prepare("INSERT INTO OUVRIERS (ID_OUV, NOM_OUV, PRENOM_OUV, AGE_OUV, NUM_TEL, FONCTION, SALAIRE_M, HTS, CONGE_A, PRIME_A) "
                    "VALUES (:idOuv, :nom, :prenom, :age, :numTel, :fonction, :salaireM, :HTS, :congeA, :primeA)");
query.bindValue(":idOuv", res);
query.bindValue(":nom", nom);
query.bindValue(":prenom", prenom);
query.bindValue(":age",res1);
query.bindValue(":numTel",res2);
query.bindValue(":fonction",fonction);
query.bindValue(":salaireM",res3);
query.bindValue(":HTS",res4);
query.bindValue(":congeA",res5);
query.bindValue(":primeA",res6);

return    query.exec();
}


QSqlQueryModel * ouvriers::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from OUVRIERS order by ID_OUV ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Age"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("numéro de téléphone"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("fonction"));
model->setHeaderData(6, Qt::Horizontal, QObject::tr("salaire/M"));
model->setHeaderData(7, Qt::Horizontal, QObject::tr("HTS"));
model->setHeaderData(8, Qt::Horizontal, QObject::tr("congé/ans"));
model->setHeaderData(9, Qt::Horizontal, QObject::tr("Prime/ans"));
    return model;
}

QSqlQueryModel * ouvriers::afficher2()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from OUVRIERS order by SALAIRE_M ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Age"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("numéro de téléphone"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("fonction"));
model->setHeaderData(6, Qt::Horizontal, QObject::tr("salaire/M"));
model->setHeaderData(7, Qt::Horizontal, QObject::tr("HTS"));
model->setHeaderData(8, Qt::Horizontal, QObject::tr("congé/ans"));
model->setHeaderData(9, Qt::Horizontal, QObject::tr("Prime/ans"));
    return model;
}
QSqlQueryModel * ouvriers::afficher3()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from OUVRIERS order by AGE_OUV ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Age"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("numéro de téléphone"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("fonction"));
model->setHeaderData(6, Qt::Horizontal, QObject::tr("salaire/M"));
model->setHeaderData(7, Qt::Horizontal, QObject::tr("HTS"));
model->setHeaderData(8, Qt::Horizontal, QObject::tr("congé/ans"));
model->setHeaderData(9, Qt::Horizontal, QObject::tr("Prime/ans"));
    return model;
}
QSqlQueryModel * ouvriers::afficher4()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from OUVRIERS order by HTS ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Age"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("numéro de téléphone"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("fonction"));
model->setHeaderData(6, Qt::Horizontal, QObject::tr("salaire/M"));
model->setHeaderData(7, Qt::Horizontal, QObject::tr("HTS"));
model->setHeaderData(8, Qt::Horizontal, QObject::tr("congé/ans"));
model->setHeaderData(9, Qt::Horizontal, QObject::tr("Prime/ans"));
    return model;
}

bool ouvriers::supprimer(int id)
{
QSqlQuery query;
QString res= QString::number(id);
query.prepare("Delete from ouvriers where ID_OUV= :id");
query.bindValue(":id", res);
return    query.exec();
}

QSqlQueryModel * ouvriers::chercher(const QString &id)
{
    QSqlQueryModel * model=new QSqlQueryModel;
   model->setQuery("select * from ouvriers where (ID_OUV LIKE '"+id+"%')");
   //model->setQuery("select * from OUVRIERS where ID_OUV='"+id+"' || NOM_OUV='"+id+"'");
   model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
   model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
   model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
   model->setHeaderData(3, Qt::Horizontal, QObject::tr("Age"));
   model->setHeaderData(4, Qt::Horizontal, QObject::tr("numéro de téléphone"));
   model->setHeaderData(5, Qt::Horizontal, QObject::tr("fonction"));
   model->setHeaderData(6, Qt::Horizontal, QObject::tr("salaire/M"));
   model->setHeaderData(7, Qt::Horizontal, QObject::tr("HTS"));
   model->setHeaderData(8, Qt::Horizontal, QObject::tr("congé/ans"));
   model->setHeaderData(9, Qt::Horizontal, QObject::tr("Prime/ans"));
    return model;
}

bool ouvriers::modifier(int id)
{
    QSqlQuery query;
    QString res= QString::number(id);
    QString res1= QString::number(age);
    QString res2= QString::number(numTel);
    QString res3= QString::number(salaireM);
    QString res4= QString::number(HTS);
    QString res5= QString::number(congeA);
    QString res6= QString::number(primeA);
    query.prepare("update ouvriers SET ID_OUV=:id,NOM_OUV=:nom,PRENOM_OUV=:prenom,AGE_OUV=:age,NUM_TEL=:numTel,FONCTION=:fonction,SALAIRE_M=:salaireM,HTS=:HTS,CONGE_A=:congeA,PRIME_A=:primeA where ID_OUV =:id");
    query.bindValue(":id", res);
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":age",res1);
    query.bindValue(":numTel",res2);
    query.bindValue(":fonction",fonction);
    query.bindValue(":salaireM",res3);
    query.bindValue(":HTS",res4);
    query.bindValue(":congeA",res5);
    query.bindValue(":primeA",res6);

    return query.exec();

}
