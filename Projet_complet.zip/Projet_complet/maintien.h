#ifndef MAINTIEN_H
#define MAINTIEN_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDateTime>
class Maintien
{
public:
    Maintien();
    Maintien(int materielId,int agentId, int Id, QString date, int cout);

    QSqlQueryModel * afficher();
    QSqlQueryModel * afficher(QString date1, QString date2);


    bool ajouter();
    bool modifier();
    bool supprimer(int idd);


private:
    int agentId;
    int materielId;
    int Id;
    QString date;
    int cout;
};

#endif // MAINTIEN_H
