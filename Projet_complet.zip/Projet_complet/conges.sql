--------------------------------------------------------
--  Fichier cr�� - dimanche-avril-26-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CONGES
--------------------------------------------------------

  CREATE TABLE "SKANDER"."CONGES" 
   (	"ID_CON" NUMBER, 
	"ID_OUV" NUMBER, 
	"NOM_OUV" VARCHAR2(20 BYTE), 
	"DUREE" NUMBER, 
	"DATE_D" DATE, 
	"P_NONP" VARCHAR2(20 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into SKANDER.CONGES
SET DEFINE OFF;
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('11','1','skander','12',to_date('01/01/00','DD/MM/RR'),'Paye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('6','1','skander','5',to_date('01/01/16','DD/MM/RR'),'Paye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('2','1','skander','2',to_date('01/02/10','DD/MM/RR'),'Paye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('3','1','skander','20',to_date('01/02/12','DD/MM/RR'),'Paye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('4','1','skander','20',to_date('01/03/14','DD/MM/RR'),'Paye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('7','1','skander','5',to_date('01/08/14','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('9','1','skander','15',to_date('01/03/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('90','1','skander','10',to_date('01/03/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('98','1','skander','10',to_date('01/03/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('100','1','skander','10',to_date('01/03/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('5','1','skander','5',to_date('01/01/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('977','1','skander','5',to_date('01/09/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('9777','1','skander','5',to_date('01/09/00','DD/MM/RR'),'NonPaye');
Insert into SKANDER.CONGES (ID_CON,ID_OUV,NOM_OUV,DUREE,DATE_D,P_NONP) values ('888','1','skander','5',to_date('01/09/50','DD/MM/RR'),'Paye');
--------------------------------------------------------
--  DDL for Index CONGES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SKANDER"."CONGES_PK" ON "SKANDER"."CONGES" ("ID_CON") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table CONGES
--------------------------------------------------------

  ALTER TABLE "SKANDER"."CONGES" ADD CONSTRAINT "CONGES_PK" PRIMARY KEY ("ID_CON")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
 
  ALTER TABLE "SKANDER"."CONGES" MODIFY ("ID_CON" NOT NULL ENABLE);
