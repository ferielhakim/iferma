#include "maintien.h"
#include <QDebug>
#include <QSqlRecord>

using namespace std;
Maintien::Maintien()
{

}

Maintien::Maintien(int materielId,int agentId, int Id, QString date, int cout)
{
    this->Id=Id;
    this->agentId=agentId;
    this->materielId=materielId;
    this->date=date;
    this->cout=cout;
}

bool Maintien::ajouter(){

    QSqlQuery query;
    QString aid= QString::number(agentId);
    QString mid= QString::number(materielId);
    QString cou= QString::number(cout);
    QString id= QString::number(Id);

    query.prepare("INSERT INTO maintien (ID, AGENT_ID, MATéRIEL_ID, H_DATE, COUT) "
                  "VALUES (:id, :aid, :mid, :date, :cou)");
    query.bindValue(":aid", aid);
    query.bindValue(":mid", mid);
    query.bindValue(":cou", cou);
    query.bindValue(":date",date);
    query.bindValue(":id", id);


    qDebug() <<"aid:  " << aid;
    qDebug() <<"mid:  " << mid;
    qDebug() <<"id:  " << id;
    qDebug() <<"cou:  " << cou;
    qDebug() <<"date:  " << date;

    return    query.exec();
}

QSqlQueryModel * Maintien::afficher()
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select ID, AGENT_ID, MATéRIEL_ID, H_DATE, COUT from maintien");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("AGENT_ID"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("MATERIEL_ID"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("H_DATE"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("COUT"));

    return model;
}

QSqlQueryModel * Maintien::afficher(QString date1, QString date2)
{
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select ID, AGENT_ID, MATéRIEL_ID, H_DATE, COUT from maintien where H_DATE>= " + date1 + " and H_DATE<= " + date2 );
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("AGENT_ID"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("MATERIEL_ID"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("H_DATE"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("COUT"));

    return model;
}

bool Maintien::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from maintien where ID = :id");
query.bindValue(":id", res);
return    query.exec();
}

bool Maintien::modifier(){
    QSqlQuery query;
    QString id_res= QString::number(Id);
    query.prepare("UPDATE Maintien SET MATéRIEL_ID = :materielId, agent_Id=:agentId, cout=:cout, h_date=:date where ID = :id");
    query.bindValue(":id", id_res);
    query.bindValue(":materielId", materielId);
    query.bindValue(":agentId", agentId);
    query.bindValue(":cout", cout);
    query.bindValue(":date", date);
    return    query.exec();
}


